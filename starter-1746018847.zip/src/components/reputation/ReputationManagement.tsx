import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  RefreshCw,
  Filter,
  Star,
  Search,
  MoreHorizontal,
  MessageSquare,
  ThumbsUp,
  ThumbsDown,
  AlertCircle,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  ChevronDown,
  ChevronUp,
  PlusCircle,
  Download,
  BarChart4,
  LineChart,
  PieChart,
  TrendingUp,
  TrendingDown,
  Calendar,
  Bell,
  Settings,
  HelpCircle,
  ExternalLink,
  Send,
  Trash2,
  Edit,
  Copy,
  Save,
  X,
  Info,
  AlertTriangle,
  Sparkles,
  Zap,
  Globe,
  Facebook,
  Twitter,
  Instagram,
  Linkedin,
  MapPin,
  Phone,
  Mail,
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const ReputationManagement = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");
  const [timeRange, setTimeRange] = useState("30days");
  const [selectedReview, setSelectedReview] = useState(null);
  const [responseDialogOpen, setResponseDialogOpen] = useState(false);
  const [responseText, setResponseText] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // Mock data for reviews
  const reviews = [
    {
      id: 1,
      source: "Google",
      sourceIcon: <Globe className="h-4 w-4 text-blue-500" />,
      rating: 5,
      customer: "Alex Johnson",
      customerAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alex",
      review:
        "Excellent service! The AI assistant was incredibly helpful and saved me a lot of time.",
      sentiment: "positive",
      status: "responded",
      date: "2023-11-10",
      response:
        "Thank you for your kind words, Alex! We're thrilled to hear that our AI assistant was helpful.",
    },
    {
      id: 2,
      source: "Facebook",
      sourceIcon: <Facebook className="h-4 w-4 text-blue-600" />,
      rating: 4,
      customer: "Sarah Williams",
      customerAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah",
      review:
        "Great platform overall. Would love to see more customization options in the future.",
      sentiment: "positive",
      status: "pending",
      date: "2023-11-08",
    },
    {
      id: 3,
      source: "Yelp",
      sourceIcon: <Star className="h-4 w-4 text-red-500" />,
      rating: 2,
      customer: "Michael Chen",
      customerAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Michael",
      review:
        "Had some issues with the integration. Customer support was slow to respond.",
      sentiment: "negative",
      status: "flagged",
      date: "2023-11-05",
    },
    {
      id: 4,
      source: "Trustpilot",
      sourceIcon: <Star className="h-4 w-4 text-green-500" />,
      rating: 5,
      customer: "Emily Rodriguez",
      customerAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Emily",
      review:
        "The automation features have transformed our business processes. Highly recommend!",
      sentiment: "positive",
      status: "responded",
      date: "2023-11-03",
      response:
        "Thank you, Emily! We're glad to hear our automation features have made such a positive impact.",
    },
    {
      id: 5,
      source: "Google",
      sourceIcon: <Globe className="h-4 w-4 text-blue-500" />,
      rating: 3,
      customer: "David Kim",
      customerAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=David",
      review:
        "Decent platform but the learning curve is steep. More tutorials would be helpful.",
      sentiment: "neutral",
      status: "pending",
      date: "2023-11-01",
    },
  ];

  // Mock data for metrics
  const metrics = {
    averageRating: 4.2,
    totalReviews: 127,
    responseRate: 92,
    positiveReviews: 78,
    neutralReviews: 12,
    negativeReviews: 10,
    ratingTrend: "+0.3",
    reviewsBySource: [
      { source: "Google", count: 58, percentage: 45 },
      { source: "Facebook", count: 32, percentage: 25 },
      { source: "Yelp", count: 18, percentage: 14 },
      { source: "Trustpilot", count: 12, percentage: 10 },
      { source: "Others", count: 7, percentage: 6 },
    ],
    ratingDistribution: [
      { rating: 5, count: 72, percentage: 57 },
      { rating: 4, count: 32, percentage: 25 },
      { rating: 3, count: 15, percentage: 12 },
      { rating: 2, count: 5, percentage: 4 },
      { rating: 1, count: 3, percentage: 2 },
    ],
  };

  // Mock data for sources
  const sources = [
    {
      id: 1,
      name: "Google Business Profile",
      icon: <Globe className="h-5 w-5 text-blue-500" />,
      status: "connected",
      reviewCount: 58,
      averageRating: 4.3,
      lastSync: "2 hours ago",
    },
    {
      id: 2,
      name: "Facebook",
      icon: <Facebook className="h-5 w-5 text-blue-600" />,
      status: "connected",
      reviewCount: 32,
      averageRating: 4.1,
      lastSync: "3 hours ago",
    },
    {
      id: 3,
      name: "Yelp",
      icon: <Star className="h-5 w-5 text-red-500" />,
      status: "connected",
      reviewCount: 18,
      averageRating: 3.8,
      lastSync: "5 hours ago",
    },
    {
      id: 4,
      name: "Trustpilot",
      icon: <Star className="h-5 w-5 text-green-500" />,
      status: "connected",
      reviewCount: 12,
      averageRating: 4.5,
      lastSync: "6 hours ago",
    },
    {
      id: 5,
      name: "LinkedIn",
      icon: <Linkedin className="h-5 w-5 text-blue-700" />,
      status: "disconnected",
      reviewCount: 0,
      averageRating: 0,
      lastSync: "Never",
    },
  ];

  // Mock response templates
  const responseTemplates = [
    {
      id: 1,
      title: "Positive Review Response",
      content:
        "Thank you for your kind words! We're thrilled to hear that you had a positive experience with our service. Your feedback means a lot to us, and we look forward to serving you again in the future.",
    },
    {
      id: 2,
      title: "Negative Review Response",
      content:
        "We're sorry to hear about your experience. We strive to provide excellent service to all our customers, and we'd like to learn more about what happened. Please contact our support team at support@captivite.com so we can address your concerns directly.",
    },
    {
      id: 3,
      title: "Neutral Review Response",
      content:
        "Thank you for sharing your feedback. We appreciate your honest review and are always looking for ways to improve. If you have any specific suggestions, please don't hesitate to reach out to us directly.",
    },
  ];

  // Function to handle review response
  const handleReviewResponse = (review) => {
    setSelectedReview(review);
    setResponseText(review.response || "");
    setResponseDialogOpen(true);
  };

  // Function to submit response
  const submitResponse = () => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      setResponseDialogOpen(false);
      toast({
        title: "Response submitted",
        description: "Your response has been published successfully.",
        variant: "success",
      });
    }, 1000);
  };

  // Function to apply template
  const applyTemplate = (template) => {
    setResponseText(template.content);
  };

  // Function to get sentiment badge
  const getSentimentBadge = (sentiment) => {
    switch (sentiment) {
      case "positive":
        return (
          <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
            <ThumbsUp className="h-3 w-3 mr-1" /> Positive
          </Badge>
        );
      case "negative":
        return (
          <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
            <ThumbsDown className="h-3 w-3 mr-1" /> Negative
          </Badge>
        );
      case "neutral":
        return (
          <Badge variant="outline" className="text-orange-600">
            <AlertCircle className="h-3 w-3 mr-1" /> Neutral
          </Badge>
        );
      default:
        return <Badge variant="outline">{sentiment}</Badge>;
    }
  };

  // Function to get status badge
  const getStatusBadge = (status) => {
    switch (status) {
      case "responded":
        return (
          <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">
            <CheckCircle2 className="h-3 w-3 mr-1" /> Responded
          </Badge>
        );
      case "pending":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
            <Clock className="h-3 w-3 mr-1" /> Pending
          </Badge>
        );
      case "flagged":
        return (
          <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
            <AlertTriangle className="h-3 w-3 mr-1" /> Flagged
          </Badge>
        );
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  // Function to render star rating
  const renderStarRating = (rating) => {
    return (
      <div className="flex">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            className={`h-4 w-4 ${i < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Reputation Management
            </h1>
            <p className="text-gray-500 mt-1">
              Monitor and manage your online reputation across all platforms
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select time range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7days">Last 7 days</SelectItem>
                <SelectItem value="30days">Last 30 days</SelectItem>
                <SelectItem value="90days">Last 90 days</SelectItem>
                <SelectItem value="year">Last year</SelectItem>
                <SelectItem value="custom">Custom range</SelectItem>
              </SelectContent>
            </Select>
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" className="text-sm">
                  <MessageSquare className="h-4 w-4 mr-2" /> Response Templates
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>Response Templates</DialogTitle>
                  <DialogDescription>
                    Manage your pre-written responses for different review
                    types.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 my-4 max-h-[400px] overflow-y-auto">
                  {responseTemplates.map((template) => (
                    <Card key={template.id} className="overflow-hidden">
                      <CardHeader className="p-4 pb-2">
                        <div className="flex justify-between items-center">
                          <CardTitle className="text-base">
                            {template.title}
                          </CardTitle>
                          <div className="flex gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                            >
                              <Copy className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-red-500 hover:text-red-600"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="p-4 pt-0">
                        <p className="text-sm text-gray-600">
                          {template.content}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                <DialogFooter>
                  <Button variant="outline">
                    <PlusCircle className="h-4 w-4 mr-2" /> Add New Template
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
            <Button variant="outline" className="text-sm">
              <Settings className="h-4 w-4 mr-2" /> Settings
            </Button>
          </div>
        </div>

        {/* Metrics Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card className="bg-white">
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-medium text-gray-500">
                    Average Rating
                  </p>
                  <div className="flex items-center mt-1">
                    <h3 className="text-3xl font-bold text-gray-900 mr-2">
                      {metrics.averageRating}
                    </h3>
                    <div className="flex items-center text-green-600 text-sm font-medium">
                      <TrendingUp className="h-4 w-4 mr-1" />
                      {metrics.ratingTrend}
                    </div>
                  </div>
                </div>
                <div className="bg-yellow-100 p-2 rounded-full">
                  <Star className="h-5 w-5 text-yellow-600" />
                </div>
              </div>
              <div className="mt-4 flex">
                {renderStarRating(Math.round(metrics.averageRating))}
                <span className="text-xs text-gray-500 ml-2">
                  ({metrics.totalReviews} reviews)
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white">
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-medium text-gray-500">
                    Response Rate
                  </p>
                  <div className="flex items-center mt-1">
                    <h3 className="text-3xl font-bold text-gray-900 mr-2">
                      {metrics.responseRate}%
                    </h3>
                  </div>
                </div>
                <div className="bg-blue-100 p-2 rounded-full">
                  <MessageSquare className="h-5 w-5 text-blue-600" />
                </div>
              </div>
              <div className="mt-4">
                <Progress value={metrics.responseRate} className="h-2" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white">
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-medium text-gray-500">
                    Sentiment Analysis
                  </p>
                  <div className="flex items-center mt-1">
                    <h3 className="text-3xl font-bold text-gray-900 mr-2">
                      {metrics.positiveReviews}%
                    </h3>
                    <span className="text-sm text-gray-500">positive</span>
                  </div>
                </div>
                <div className="bg-green-100 p-2 rounded-full">
                  <ThumbsUp className="h-5 w-5 text-green-600" />
                </div>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-1">
                <div
                  className="bg-green-100 h-2 rounded-l-full"
                  style={{ width: `${metrics.positiveReviews}%` }}
                ></div>
                <div
                  className="bg-yellow-100 h-2"
                  style={{ width: `${metrics.neutralReviews}%` }}
                ></div>
                <div
                  className="bg-red-100 h-2 rounded-r-full"
                  style={{ width: `${metrics.negativeReviews}%` }}
                ></div>
              </div>
              <div className="mt-1 flex justify-between text-xs text-gray-500">
                <span>Positive: {metrics.positiveReviews}%</span>
                <span>Neutral: {metrics.neutralReviews}%</span>
                <span>Negative: {metrics.negativeReviews}%</span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white">
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-medium text-gray-500">
                    Total Reviews
                  </p>
                  <div className="flex items-center mt-1">
                    <h3 className="text-3xl font-bold text-gray-900 mr-2">
                      {metrics.totalReviews}
                    </h3>
                  </div>
                </div>
                <div className="bg-purple-100 p-2 rounded-full">
                  <BarChart4 className="h-5 w-5 text-purple-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-500 rounded-full mr-1"></div>
                  <span className="text-xs text-gray-500">This month: 24</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-blue-500 rounded-full mr-1"></div>
                  <span className="text-xs text-gray-500">Last month: 18</span>
                </div>
                <div className="flex items-center">
                  <TrendingUp className="h-3 w-3 text-green-500 mr-1" />
                  <span className="text-xs text-green-500">+33%</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
          <Tabs
            defaultValue={activeTab}
            onValueChange={setActiveTab}
            className="w-full"
          >
            <div className="border-b px-6 py-4">
              <TabsList className="bg-gray-100">
                <TabsTrigger
                  value="overview"
                  className="data-[state=active]:bg-white"
                >
                  <BarChart4 className="h-4 w-4 mr-2" /> Overview
                </TabsTrigger>
                <TabsTrigger
                  value="reviews"
                  className="data-[state=active]:bg-white"
                >
                  <MessageSquare className="h-4 w-4 mr-2" /> Reviews
                </TabsTrigger>
                <TabsTrigger
                  value="sources"
                  className="data-[state=active]:bg-white"
                >
                  <Globe className="h-4 w-4 mr-2" /> Sources
                </TabsTrigger>
                <TabsTrigger
                  value="analytics"
                  className="data-[state=active]:bg-white"
                >
                  <LineChart className="h-4 w-4 mr-2" /> Analytics
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="overview" className="p-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Recent Reviews */}
                <Card>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <div>
                        <CardTitle>Recent Reviews</CardTitle>
                        <CardDescription>
                          Your most recent customer feedback across all
                          platforms
                        </CardDescription>
                      </div>
                      <Button variant="ghost" size="sm">
                        <ArrowUpRight className="h-4 w-4 mr-1" /> View All
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {reviews.slice(0, 3).map((review) => (
                        <div
                          key={review.id}
                          className="border rounded-lg p-4 hover:bg-gray-50 transition-colors"
                        >
                          <div className="flex justify-between items-start mb-2">
                            <div className="flex items-center">
                              <Avatar className="h-8 w-8 mr-2">
                                <AvatarImage
                                  src={review.customerAvatar}
                                  alt={review.customer}
                                />
                                <AvatarFallback>
                                  {review.customer.charAt(0)}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-medium text-sm">
                                  {review.customer}
                                </p>
                                <div className="flex items-center text-xs text-gray-500">
                                  {review.sourceIcon}
                                  <span className="ml-1">{review.source}</span>
                                  <span className="mx-1">•</span>
                                  <span>{review.date}</span>
                                </div>
                              </div>
                            </div>
                            <div className="flex">
                              {renderStarRating(review.rating)}
                            </div>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">
                            {review.review}
                          </p>
                          <div className="flex justify-between items-center">
                            <div className="flex space-x-2">
                              {getSentimentBadge(review.sentiment)}
                              {getStatusBadge(review.status)}
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleReviewResponse(review)}
                              className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                            >
                              <MessageSquare className="h-4 w-4 mr-1" />
                              {review.status === "responded"
                                ? "View Response"
                                : "Respond"}
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Rating Distribution */}
                <Card>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <div>
                        <CardTitle>Rating Distribution</CardTitle>
                        <CardDescription>
                          Breakdown of ratings across all platforms
                        </CardDescription>
                      </div>
                      <Select defaultValue="all">
                        <SelectTrigger className="w-[130px] h-8 text-xs">
                          <SelectValue placeholder="Filter by source" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Sources</SelectItem>
                          <SelectItem value="google">Google</SelectItem>
                          <SelectItem value="facebook">Facebook</SelectItem>
                          <SelectItem value="yelp">Yelp</SelectItem>
                          <SelectItem value="trustpilot">Trustpilot</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {metrics.ratingDistribution.map((item) => (
                        <div key={item.rating} className="flex items-center">
                          <div className="w-12 text-sm font-medium">
                            {item.rating} stars
                          </div>
                          <div className="flex-1 mx-3">
                            <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                              <div
                                className="h-full bg-yellow-400"
                                style={{ width: `${item.percentage}%` }}
                              ></div>
                            </div>
                          </div>
                          <div className="w-12 text-sm text-gray-500 text-right">
                            {item.count} ({item.percentage}%)
                          </div>
                        </div>
                      ))}
                    </div>

                    <Separator className="my-6" />

                    <div>
                      <h4 className="text-sm font-medium mb-4">
                        Reviews by Source
                      </h4>
                      <div className="grid grid-cols-2 gap-4">
                        {metrics.reviewsBySource.map((item) => (
                          <div key={item.source} className="flex items-center">
                            <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center mr-2">
                              {item.source === "Google" && (
                                <Globe className="h-4 w-4 text-blue-500" />
                              )}
                              {item.source === "Facebook" && (
                                <Facebook className="h-4 w-4 text-blue-600" />
                              )}
                              {item.source === "Yelp" && (
                                <Star className="h-4 w-4 text-red-500" />
                              )}
                              {item.source === "Trustpilot" && (
                                <Star className="h-4 w-4 text-green-500" />
                              )}
                              {item.source === "Others" && (
                                <Globe className="h-4 w-4 text-gray-500" />
                              )}
                            </div>
                            <div>
                              <p className="text-sm font-medium">
                                {item.source}
                              </p>
                              <p className="text-xs text-gray-500">
                                {item.count} reviews ({item.percentage}%)
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* AI Insights */}
                <Card className="bg-gradient-to-br from-indigo-50 to-purple-50 border-indigo-100">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <div className="bg-indigo-100 p-1.5 rounded-lg mr-2">
                          <Sparkles className="h-5 w-5 text-indigo-600" />
                        </div>
                        <div>
                          <CardTitle className="flex items-center">
                            AI-Powered Insights
                            <Badge className="ml-2 bg-indigo-100 text-indigo-800 hover:bg-indigo-200">
                              <Zap className="h-3 w-3 mr-1" /> New
                            </Badge>
                          </CardTitle>
                          <CardDescription>
                            Smart analysis of your reputation data
                          </CardDescription>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="bg-white rounded-lg p-4 border border-indigo-100 shadow-sm">
                        <div className="flex items-start">
                          <div className="bg-green-100 p-1.5 rounded-lg mr-3">
                            <TrendingUp className="h-4 w-4 text-green-600" />
                          </div>
                          <div>
                            <h4 className="text-sm font-medium mb-1">
                              Positive Trend Detected
                            </h4>
                            <p className="text-sm text-gray-600">
                              Your average rating has increased by 0.3 stars
                              over the past 30 days. Keep up the good work!
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="bg-white rounded-lg p-4 border border-indigo-100 shadow-sm">
                        <div className="flex items-start">
                          <div className="bg-yellow-100 p-1.5 rounded-lg mr-3">
                            <MessageSquare className="h-4 w-4 text-yellow-600" />
                          </div>
                          <div>
                            <h4 className="text-sm font-medium mb-1">
                              Common Feedback Theme
                            </h4>
                            <p className="text-sm text-gray-600">
                              Multiple customers have mentioned your "excellent
                              customer service" in recent reviews. This is a key
                              strength to highlight in your marketing.
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="bg-white rounded-lg p-4 border border-indigo-100 shadow-sm">
                        <div className="flex items-start">
                          <div className="bg-blue-100 p-1.5 rounded-lg mr-3">
                            <AlertCircle className="h-4 w-4 text-blue-600" />
                          </div>
                          <div>
                            <h4 className="text-sm font-medium mb-1">
                              Suggested Action
                            </h4>
                            <p className="text-sm text-gray-600">
                              You have 2 negative reviews that haven't received
                              responses. Responding promptly can improve
                              customer satisfaction.
                            </p>
                            <Button
                              variant="link"
                              className="text-xs p-0 h-auto mt-1 text-indigo-600 hover:text-indigo-800"
                            >
                              View pending reviews
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Competitor Analysis */}
                <Card>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <div>
                        <CardTitle>Competitor Analysis</CardTitle>
                        <CardDescription>
                          How your reputation compares to competitors
                        </CardDescription>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Settings className="h-4 w-4 mr-1" /> Configure
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div>
                        <h4 className="text-sm font-medium mb-3">
                          Average Rating Comparison
                        </h4>
                        <div className="space-y-3">
                          {[
                            {
                              name: "Your Business",
                              rating: 4.2,
                              reviews: 127,
                              color: "bg-blue-500",
                            },
                            {
                              name: "Competitor A",
                              rating: 3.8,
                              reviews: 98,
                              color: "bg-gray-400",
                            },
                            {
                              name: "Competitor B",
                              rating: 4.5,
                              reviews: 156,
                              color: "bg-gray-400",
                            },
                            {
                              name: "Industry Average",
                              rating: 4.0,
                              reviews: null,
                              color: "bg-gray-300",
                            },
                          ].map((item) => (
                            <div key={item.name} className="space-y-1">
                              <div className="flex justify-between items-center text-sm">
                                <span className="font-medium">{item.name}</span>
                                <div className="flex items-center">
                                  <span className="font-bold mr-1">
                                    {item.rating}
                                  </span>
                                  <div className="flex">
                                    {[...Array(5)].map((_, i) => (
                                      <Star
                                        key={i}
                                        className={`h-3 w-3 ${i < Math.round(item.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                                      />
                                    ))}
                                  </div>
                                  {item.reviews && (
                                    <span className="text-xs text-gray-500 ml-1">
                                      ({item.reviews})
                                    </span>
                                  )}
                                </div>
                              </div>
                              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                                <div
                                  className={`h-full ${item.color}`}
                                  style={{
                                    width: `${(item.rating / 5) * 100}%`,
                                  }}
                                ></div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h4 className="text-sm font-medium mb-3">
                          Review Volume Trend
                        </h4>
                        <div className="h-[120px] bg-gray-50 rounded-lg flex items-center justify-center">
                          <p className="text-sm text-gray-500">
                            Review volume trend chart
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="reviews" className="p-6">
              <div className="mb-6 flex flex-col sm:flex-row justify-between gap-4">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input placeholder="Search reviews..." className="pl-10" />
                </div>
                <div className="flex flex-wrap gap-2">
                  <Select defaultValue="all">
                    <SelectTrigger className="w-[130px]">
                      <SelectValue placeholder="Source" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Sources</SelectItem>
                      <SelectItem value="google">Google</SelectItem>
                      <SelectItem value="facebook">Facebook</SelectItem>
                      <SelectItem value="yelp">Yelp</SelectItem>
                      <SelectItem value="trustpilot">Trustpilot</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select defaultValue="all">
                    <SelectTrigger className="w-[130px]">
                      <SelectValue placeholder="Rating" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Ratings</SelectItem>
                      <SelectItem value="5">5 Stars</SelectItem>
                      <SelectItem value="4">4 Stars</SelectItem>
                      <SelectItem value="3">3 Stars</SelectItem>
                      <SelectItem value="2">2 Stars</SelectItem>
                      <SelectItem value="1">1 Star</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select defaultValue="all">
                    <SelectTrigger className="w-[130px]">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="responded">Responded</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="flagged">Flagged</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="icon">
                    <Filter className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon">
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="bg-white border rounded-lg overflow-hidden">
                <div className="grid grid-cols-12 gap-4 p-4 border-b bg-gray-50 text-sm font-medium text-gray-500">
                  <div className="col-span-3">Customer / Source</div>
                  <div className="col-span-1 text-center">Rating</div>
                  <div className="col-span-4">Review</div>
                  <div className="col-span-1">Sentiment</div>
                  <div className="col-span-1">Status</div>
                  <div className="col-span-1">Date</div>
                  <div className="col-span-1 text-right">Actions</div>
                </div>

                {reviews.length > 0 ? (
                  <div className="divide-y">
                    {reviews.map((review) => (
                      <div
                        key={review.id}
                        className="grid grid-cols-12 gap-4 p-4 items-center hover:bg-gray-50 transition-colors"
                      >
                        <div className="col-span-3">
                          <div className="flex items-center">
                            <Avatar className="h-8 w-8 mr-2">
                              <AvatarImage
                                src={review.customerAvatar}
                                alt={review.customer}
                              />
                              <AvatarFallback>
                                {review.customer.charAt(0)}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium text-sm">
                                {review.customer}
                              </p>
                              <div className="flex items-center text-xs text-gray-500">
                                {review.sourceIcon}
                                <span className="ml-1">{review.source}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-span-1 text-center">
                          {renderStarRating(review.rating)}
                        </div>
                        <div className="col-span-4">
                          <p className="text-sm text-gray-700 line-clamp-2">
                            {review.review}
                          </p>
                          {review.response && (
                            <div className="mt-2 text-xs text-gray-500 bg-gray-50 p-2 rounded border-l-2 border-blue-400">
                              <span className="font-medium">
                                Your response:
                              </span>{" "}
                              {review.response.length > 60
                                ? `${review.response.substring(0, 60)}...`
                                : review.response}
                            </div>
                          )}
                        </div>
                        <div className="col-span-1">
                          {getSentimentBadge(review.sentiment)}
                        </div>
                        <div className="col-span-1">
                          {getStatusBadge(review.status)}
                        </div>
                        <div className="col-span-1 text-sm text-gray-500">
                          {review.date}
                        </div>
                        <div className="col-span-1 text-right">
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                              >
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-48" align="end">
                              <div className="space-y-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="w-full justify-start"
                                  onClick={() => handleReviewResponse(review)}
                                >
                                  <MessageSquare className="h-4 w-4 mr-2" />
                                  {review.status === "responded"
                                    ? "View Response"
                                    : "Respond"}
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="w-full justify-start"
                                >
                                  <ExternalLink className="h-4 w-4 mr-2" />
                                  View on {review.source}
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="w-full justify-start"
                                >
                                  <AlertTriangle className="h-4 w-4 mr-2" />
                                  Flag Review
                                </Button>
                              </div>
                            </PopoverContent>
                          </Popover>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-8 text-center text-gray-500">
                    <MessageSquare className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                    <p>No reviews found. Try adjusting your filters.</p>
                  </div>
                )}

                <div className="p-4 border-t bg-gray-50 flex items-center justify-between">
                  <p className="text-sm text-gray-500">
                    Showing <span className="font-medium">1</span> to{" "}
                    <span className="font-medium">{reviews.length}</span> of{" "}
                    <span className="font-medium">{metrics.totalReviews}</span>{" "}
                    reviews
                  </p>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm" disabled>
                      Previous
                    </Button>
                    <Button variant="outline" size="sm" className="w-8 p-0">
                      1
                    </Button>
                    <Button variant="outline" size="sm" className="w-8 p-0">
                      2
                    </Button>
                    <Button variant="outline" size="sm" className="w-8 p-0">
                      3
                    </Button>
                    <Button variant="outline" size="sm">
                      Next
                    </Button>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="sources" className="p-6">
              <div className="mb-6 flex justify-between items-center">
                <h3 className="text-lg font-medium">
                  Connected Review Sources
                </h3>
                <Button>
                  <PlusCircle className="h-4 w-4 mr-2" /> Add New Source
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                {sources.map((source) => (
                  <Card
                    key={source.id}
                    className={`${source.status === "disconnected" ? "bg-gray-50" : "bg-white"}`}
                  >
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center">
                          <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center mr-3">
                            {source.icon}
                          </div>
                          <div>
                            <h4 className="font-medium">{source.name}</h4>
                            <Badge
                              variant={
                                source.status === "connected"
                                  ? "outline"
                                  : "secondary"
                              }
                              className={
                                source.status === "connected"
                                  ? "text-green-600 bg-green-50"
                                  : "text-gray-500"
                              }
                            >
                              {source.status === "connected"
                                ? "Connected"
                                : "Disconnected"}
                            </Badge>
                          </div>
                        </div>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </div>

                      {source.status === "connected" ? (
                        <>
                          <div className="grid grid-cols-2 gap-4 mb-4">
                            <div>
                              <p className="text-xs text-gray-500">Reviews</p>
                              <p className="font-medium">
                                {source.reviewCount}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-500">
                                Average Rating
                              </p>
                              <div className="flex items-center">
                                <p className="font-medium mr-1">
                                  {source.averageRating}
                                </p>
                                <Star className="h-3 w-3 text-yellow-400 fill-yellow-400" />
                              </div>
                            </div>
                          </div>
                          <div className="flex justify-between items-center text-xs text-gray-500">
                            <span>Last synced: {source.lastSync}</span>
                            <Button
                              variant="link"
                              className="h-auto p-0 text-xs"
                            >
                              Sync Now
                            </Button>
                          </div>
                        </>
                      ) : (
                        <div className="mt-4">
                          <Button className="w-full" size="sm">
                            Connect Account
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Source Settings</CardTitle>
                  <CardDescription>
                    Configure how reviews are collected and managed
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="auto-sync">Automatic Sync</Label>
                        <p className="text-sm text-gray-500">
                          Automatically sync reviews from all connected sources
                        </p>
                      </div>
                      <Switch id="auto-sync" defaultChecked />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="auto-respond">Auto-Response</Label>
                        <p className="text-sm text-gray-500">
                          Automatically respond to new reviews using AI
                          templates
                        </p>
                      </div>
                      <Switch id="auto-respond" />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="notifications">
                          Email Notifications
                        </Label>
                        <p className="text-sm text-gray-500">
                          Receive email notifications for new reviews
                        </p>
                      </div>
                      <Switch id="notifications" defaultChecked />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analytics" className="p-6">
              <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h3 className="text-lg font-medium">Reputation Analytics</h3>
                <div className="flex gap-2">
                  <Select value={timeRange} onValueChange={setTimeRange}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Select time range" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7days">Last 7 days</SelectItem>
                      <SelectItem value="30days">Last 30 days</SelectItem>
                      <SelectItem value="90days">Last 90 days</SelectItem>
                      <SelectItem value="year">Last year</SelectItem>
                      <SelectItem value="custom">Custom range</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" /> Export
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle>Rating Trend</CardTitle>
                    <CardDescription>
                      How your average rating has changed over time
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px] bg-gray-50 rounded-lg flex items-center justify-center">
                      <p className="text-gray-500">Rating trend chart</p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle>Review Volume</CardTitle>
                    <CardDescription>
                      Number of reviews received over time
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px] bg-gray-50 rounded-lg flex items-center justify-center">
                      <p className="text-gray-500">Review volume chart</p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle>Sentiment Analysis</CardTitle>
                    <CardDescription>
                      Breakdown of review sentiment over time
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px] bg-gray-50 rounded-lg flex items-center justify-center">
                      <p className="text-gray-500">Sentiment analysis chart</p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle>Common Keywords</CardTitle>
                    <CardDescription>
                      Most frequently mentioned terms in reviews
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px] bg-gray-50 rounded-lg flex items-center justify-center">
                      <p className="text-gray-500">
                        Keyword cloud visualization
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Footer */}
        <div className="flex justify-between items-center">
          <div className="flex items-center text-sm text-gray-500">
            <Info className="h-4 w-4 mr-1" />
            <span>Data last updated: Today at 10:45 AM</span>
          </div>
          <Button className="flex items-center">
            <RefreshCw className="mr-2 h-4 w-4" /> Refresh Data
          </Button>
        </div>
      </div>

      {/* Response Dialog */}
      <Dialog open={responseDialogOpen} onOpenChange={setResponseDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Respond to Review</DialogTitle>
            <DialogDescription>
              Craft a thoughtful response to this customer review.
            </DialogDescription>
          </DialogHeader>

          {selectedReview && (
            <div className="mb-4 p-4 bg-gray-50 rounded-lg">
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center">
                  <Avatar className="h-8 w-8 mr-2">
                    <AvatarImage
                      src={selectedReview.customerAvatar}
                      alt={selectedReview.customer}
                    />
                    <AvatarFallback>
                      {selectedReview.customer.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-sm">
                      {selectedReview.customer}
                    </p>
                    <div className="flex items-center text-xs text-gray-500">
                      {selectedReview.sourceIcon}
                      <span className="ml-1">{selectedReview.source}</span>
                      <span className="mx-1">•</span>
                      <span>{selectedReview.date}</span>
                    </div>
                  </div>
                </div>
                <div className="flex">
                  {renderStarRating(selectedReview.rating)}
                </div>
              </div>
              <p className="text-sm text-gray-700">{selectedReview.review}</p>
            </div>
          )}

          <div className="mb-4">
            <Label htmlFor="response" className="mb-2 block">
              Your Response
            </Label>
            <Textarea
              id="response"
              value={responseText}
              onChange={(e) => setResponseText(e.target.value)}
              placeholder="Write your response here..."
              className="min-h-[120px]"
            />
          </div>

          <div className="mb-4">
            <Label className="mb-2 block">Response Templates</Label>
            <div className="flex flex-wrap gap-2">
              {responseTemplates.map((template) => (
                <Button
                  key={template.id}
                  variant="outline"
                  size="sm"
                  onClick={() => applyTemplate(template)}
                >
                  {template.title}
                </Button>
              ))}
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setResponseDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={submitResponse}
              disabled={!responseText.trim() || isLoading}
            >
              {isLoading ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />{" "}
                  Submitting...
                </>
              ) : (
                <>
                  <Send className="mr-2 h-4 w-4" /> Submit Response
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ReputationManagement;

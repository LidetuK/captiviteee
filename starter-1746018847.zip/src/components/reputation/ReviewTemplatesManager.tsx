import { FC, useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ResponseTemplate } from "@/lib/reputation/reputationManager";
import { Plus, Pencil, Trash2, Save, X } from "lucide-react";

interface ReviewTemplatesManagerProps {
  templates: ResponseTemplate[];
  onAddTemplate?: (
    template: Omit<
      ResponseTemplate,
      "id" | "createdAt" | "updatedAt" | "usageCount" | "successRate"
    >,
  ) => void;
  onUpdateTemplate?: (id: string, template: Partial<ResponseTemplate>) => void;
  onDeleteTemplate?: (id: string) => void;
}

const ReviewTemplatesManager: FC<ReviewTemplatesManagerProps> = ({
  templates = [],
  onAddTemplate,
  onUpdateTemplate,
  onDeleteTemplate,
}) => {
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newTemplate, setNewTemplate] = useState<
    Omit<
      ResponseTemplate,
      "id" | "createdAt" | "updatedAt" | "usageCount" | "successRate"
    >
  >({
    name: "",
    category: "general",
    content: "",
    variables: [],
    sentiment: "neutral",
    tags: [],
    createdBy: "current-user", // This would come from auth context
  });

  const handleAddSubmit = () => {
    if (onAddTemplate && newTemplate.name && newTemplate.content) {
      onAddTemplate(newTemplate);
      setNewTemplate({
        name: "",
        category: "general",
        content: "",
        variables: [],
        sentiment: "neutral",
        tags: [],
        createdBy: "current-user",
      });
      setIsAdding(false);
    }
  };

  const handleEditSubmit = (id: string) => {
    if (onUpdateTemplate) {
      const template = templates.find((t) => t.id === id);
      if (template) {
        onUpdateTemplate(id, template);
        setEditingId(null);
      }
    }
  };

  const handleChange = (field: keyof typeof newTemplate, value: any) => {
    setNewTemplate((prev) => ({ ...prev, [field]: value }));
  };

  const handleEditChange = (
    id: string,
    field: keyof ResponseTemplate,
    value: any,
  ) => {
    if (onUpdateTemplate) {
      const template = templates.find((t) => t.id === id);
      if (template) {
        onUpdateTemplate(id, { ...template, [field]: value });
      }
    }
  };

  const renderTemplateForm = () => (
    <div className="space-y-4 p-4 border rounded-md">
      <div className="space-y-2">
        <Label htmlFor="name">Template Name</Label>
        <Input
          id="name"
          value={newTemplate.name}
          onChange={(e) => handleChange("name", e.target.value)}
          placeholder="e.g., Positive Review Response"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="category">Category</Label>
        <Select
          value={newTemplate.category}
          onValueChange={(value) => handleChange("category", value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="general">General</SelectItem>
            <SelectItem value="positive">Positive Reviews</SelectItem>
            <SelectItem value="negative">Negative Reviews</SelectItem>
            <SelectItem value="neutral">Neutral Reviews</SelectItem>
            <SelectItem value="product">Product Specific</SelectItem>
            <SelectItem value="service">Service Specific</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="sentiment">Sentiment</Label>
        <Select
          value={newTemplate.sentiment}
          onValueChange={(value) =>
            handleChange(
              "sentiment",
              value as "positive" | "neutral" | "negative",
            )
          }
        >
          <SelectTrigger>
            <SelectValue placeholder="Select sentiment" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="positive">Positive</SelectItem>
            <SelectItem value="neutral">Neutral</SelectItem>
            <SelectItem value="negative">Negative</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="content">Template Content</Label>
        <Textarea
          id="content"
          value={newTemplate.content}
          onChange={(e) => handleChange("content", e.target.value)}
          placeholder="Thank you {{customerName}} for your {{rating}}-star review..."
          className="min-h-[150px]"
        />
        <p className="text-xs text-muted-foreground">
          Use variables like {{ customerName }}, {{ rating }},{" "}
          {{ businessName }} that will be replaced with actual values.
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="tags">Tags (comma separated)</Label>
        <Input
          id="tags"
          value={newTemplate.tags?.join(", ") || ""}
          onChange={(e) =>
            handleChange(
              "tags",
              e.target.value
                .split(",")
                .map((tag) => tag.trim())
                .filter(Boolean),
            )
          }
          placeholder="e.g., thank you, follow up, apology"
        />
      </div>

      <div className="flex justify-end space-x-2">
        <Button variant="outline" onClick={() => setIsAdding(false)}>
          Cancel
        </Button>
        <Button
          onClick={handleAddSubmit}
          disabled={!newTemplate.name || !newTemplate.content}
        >
          Add Template
        </Button>
      </div>
    </div>
  );

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Response Templates</CardTitle>
          <CardDescription>
            Create and manage templates for responding to reviews
          </CardDescription>
        </div>
        {!isAdding && (
          <Button onClick={() => setIsAdding(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Template
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {isAdding && renderTemplateForm()}

        <div className="space-y-4 mt-4">
          {templates.length === 0 && !isAdding ? (
            <div className="text-center py-8 text-muted-foreground">
              <p>
                No templates available. Create templates to quickly respond to
                reviews.
              </p>
              <Button variant="link" onClick={() => setIsAdding(true)}>
                Create your first template
              </Button>
            </div>
          ) : (
            templates.map((template) => (
              <div key={template.id} className="border rounded-md p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h4 className="font-medium">{template.name}</h4>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs bg-muted px-2 py-0.5 rounded">
                        {template.category}
                      </span>
                      <span
                        className={`text-xs px-2 py-0.5 rounded ${template.sentiment === "positive" ? "bg-green-100 text-green-800" : template.sentiment === "negative" ? "bg-red-100 text-red-800" : "bg-gray-100 text-gray-800"}`}
                      >
                        {template.sentiment}
                      </span>
                      {template.tags?.map((tag) => (
                        <span
                          key={tag}
                          className="text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    {editingId === template.id ? (
                      <>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditSubmit(template.id)}
                        >
                          <Save className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditingId(null)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditingId(template.id)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onDeleteTemplate?.(template.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </div>

                {editingId === template.id ? (
                  <div className="space-y-4 mt-4">
                    <Textarea
                      value={template.content}
                      onChange={(e) =>
                        handleEditChange(template.id, "content", e.target.value)
                      }
                      className="min-h-[100px]"
                    />
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground mt-2">
                    {template.content}
                  </p>
                )}

                <div className="flex justify-between items-center mt-4 text-xs text-muted-foreground">
                  <span>Used {template.usageCount} times</span>
                  {template.successRate !== undefined && (
                    <span>
                      Success rate: {(template.successRate * 100).toFixed(0)}%
                    </span>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ReviewTemplatesManager;

import { FC, useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Review,
  ReviewResponse,
  ResponseTemplate,
} from "@/lib/reputation/reputationManager";
import { Star, MessageSquare, ThumbsUp, ThumbsDown } from "lucide-react";

interface ReviewResponseDialogProps {
  review?: Review;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (
    reviewId: string,
    content: string,
    status: ReviewResponse["status"],
  ) => void;
  templates?: ResponseTemplate[];
}

const ReviewResponseDialog: FC<ReviewResponseDialogProps> = ({
  review,
  open,
  onOpenChange,
  onSubmit,
  templates = [],
}) => {
  const [responseContent, setResponseContent] = useState("");
  const [activeTab, setActiveTab] = useState("write");

  useEffect(() => {
    if (review?.responseContent) {
      setResponseContent(review.responseContent);
    } else {
      setResponseContent("");
    }
  }, [review]);

  const handleSubmit = (status: ReviewResponse["status"]) => {
    if (review && responseContent.trim()) {
      onSubmit(review.id, responseContent, status);
      onOpenChange(false);
    }
  };

  const handleTemplateSelect = (template: ResponseTemplate) => {
    let content = template.content;

    // Replace variables in template
    if (review && template.variables) {
      template.variables.forEach((variable) => {
        const placeholder = `{{${variable}}}`;
        let value = "";

        switch (variable) {
          case "customerName":
            value = review.authorName;
            break;
          case "rating":
            value = review.rating.toString();
            break;
          case "businessName":
            value = "Our Business"; // This should come from a configuration
            break;
          default:
            value = "";
        }

        content = content.replace(new RegExp(placeholder, "g"), value);
      });
    }

    setResponseContent(content);
    setActiveTab("write");
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star
            key={i}
            size={16}
            className={
              i < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
            }
          />
        ))}
      </div>
    );
  };

  const getSentimentIcon = (score?: number) => {
    if (!score) return null;

    if (score > 0.2) {
      return <ThumbsUp className="h-5 w-5 text-green-500" />;
    } else if (score < -0.2) {
      return <ThumbsDown className="h-5 w-5 text-red-500" />;
    }
    return null;
  };

  if (!review) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>Respond to Review</DialogTitle>
          <DialogDescription>
            Craft a thoughtful response to this customer review.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-6">
          <div className="bg-muted/50 p-4 rounded-lg">
            <div className="flex justify-between items-start mb-2">
              <div>
                <h4 className="font-medium flex items-center gap-2">
                  {review.authorName}
                  <span className="text-sm text-muted-foreground">
                    via {review.sourceName}
                  </span>
                </h4>
                <div className="flex items-center gap-2 mt-1">
                  {renderStars(review.rating)}
                  <span className="text-sm text-muted-foreground">
                    {new Date(review.publishedAt).toLocaleDateString()}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {getSentimentIcon(review.sentiment?.score)}
                <span className="text-sm font-medium">
                  {review.sentiment?.score && review.sentiment.score > 0.2
                    ? "Positive"
                    : review.sentiment?.score && review.sentiment.score < -0.2
                      ? "Negative"
                      : "Neutral"}
                </span>
              </div>
            </div>
            {review.title && (
              <h3 className="font-medium mb-2">{review.title}</h3>
            )}
            <p className="text-sm">{review.content}</p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="write">
                <MessageSquare className="h-4 w-4 mr-2" />
                Write Response
              </TabsTrigger>
              <TabsTrigger value="templates">
                <MessageSquare className="h-4 w-4 mr-2" />
                Templates
              </TabsTrigger>
            </TabsList>
            <TabsContent value="write" className="space-y-4">
              <Textarea
                placeholder="Type your response here..."
                className="min-h-[200px]"
                value={responseContent}
                onChange={(e) => setResponseContent(e.target.value)}
              />
              <div className="text-xs text-muted-foreground">
                <p>Tips for effective responses:</p>
                <ul className="list-disc pl-4 mt-1 space-y-1">
                  <li>Thank the customer for their feedback</li>
                  <li>Address specific points mentioned in the review</li>
                  <li>Be professional and courteous</li>
                  <li>
                    Offer solutions or explain improvements if addressing a
                    negative review
                  </li>
                  <li>Invite further communication if appropriate</li>
                </ul>
              </div>
            </TabsContent>
            <TabsContent value="templates" className="space-y-4">
              <div className="grid gap-2 max-h-[300px] overflow-y-auto pr-2">
                {templates.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8">
                    No templates available. Create templates to quickly respond
                    to reviews.
                  </p>
                ) : (
                  templates.map((template) => (
                    <div
                      key={template.id}
                      className="border rounded-md p-3 cursor-pointer hover:bg-muted/50 transition-colors"
                      onClick={() => handleTemplateSelect(template)}
                    >
                      <div className="flex justify-between items-center mb-1">
                        <h4 className="font-medium text-sm">{template.name}</h4>
                        <span
                          className={`text-xs px-2 py-0.5 rounded-full ${template.sentiment === "positive" ? "bg-green-100 text-green-800" : template.sentiment === "negative" ? "bg-red-100 text-red-800" : "bg-gray-100 text-gray-800"}`}
                        >
                          {template.sentiment}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground line-clamp-2">
                        {template.content}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <DialogFooter className="flex justify-between items-center">
          <div className="text-sm text-muted-foreground">
            {review.status === "responded" ? (
              <span className="flex items-center">
                <MessageSquare className="h-4 w-4 mr-1" />
                Previously responded on{" "}
                {review.responsePublishedAt
                  ? new Date(review.responsePublishedAt).toLocaleDateString()
                  : "unknown date"}
              </span>
            ) : null}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button variant="secondary" onClick={() => handleSubmit("draft")}>
              Save as Draft
            </Button>
            <Button onClick={() => handleSubmit("published")}>
              Publish Response
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ReviewResponseDialog;

import { FC, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { ReviewSource } from "@/lib/reputation/reputationManager";

interface AddSourceDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (source: Omit<ReviewSource, "id" | "lastSyncTime">) => void;
}

const AddSourceDialog: FC<AddSourceDialogProps> = ({
  open,
  onOpenChange,
  onSubmit,
}) => {
  const [source, setSource] = useState<
    Omit<ReviewSource, "id" | "lastSyncTime">
  >({
    name: "",
    type: "google",
    url: "",
    apiKey: "",
    enabled: true,
    syncFrequency: "daily",
    credentials: {},
  });

  const handleChange = (field: keyof typeof source, value: any) => {
    setSource((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = () => {
    onSubmit(source);
    // Reset form
    setSource({
      name: "",
      type: "google",
      url: "",
      apiKey: "",
      enabled: true,
      syncFrequency: "daily",
      credentials: {},
    });
  };

  const isValid = source.name.trim() !== "";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Add Review Source</DialogTitle>
          <DialogDescription>
            Connect to a platform where your business receives reviews.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="name" className="text-right">
              Name
            </Label>
            <Input
              id="name"
              value={source.name}
              onChange={(e) => handleChange("name", e.target.value)}
              className="col-span-3"
              placeholder="My Google Business Reviews"
            />
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="type" className="text-right">
              Source Type
            </Label>
            <Select
              value={source.type}
              onValueChange={(value) =>
                handleChange("type", value as ReviewSource["type"])
              }
            >
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Select source type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="google">Google Business</SelectItem>
                <SelectItem value="yelp">Yelp</SelectItem>
                <SelectItem value="facebook">Facebook</SelectItem>
                <SelectItem value="trustpilot">Trustpilot</SelectItem>
                <SelectItem value="capterra">Capterra</SelectItem>
                <SelectItem value="g2">G2</SelectItem>
                <SelectItem value="app_store">App Store</SelectItem>
                <SelectItem value="play_store">Google Play Store</SelectItem>
                <SelectItem value="custom">Custom Source</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="url" className="text-right">
              URL
            </Label>
            <Input
              id="url"
              value={source.url || ""}
              onChange={(e) => handleChange("url", e.target.value)}
              className="col-span-3"
              placeholder="https://business.google.com/..."
            />
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="apiKey" className="text-right">
              API Key
            </Label>
            <Input
              id="apiKey"
              value={source.apiKey || ""}
              onChange={(e) => handleChange("apiKey", e.target.value)}
              className="col-span-3"
              type="password"
              placeholder="Optional API key for this source"
            />
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="syncFrequency" className="text-right">
              Sync Frequency
            </Label>
            <Select
              value={source.syncFrequency}
              onValueChange={(value) =>
                handleChange(
                  "syncFrequency",
                  value as ReviewSource["syncFrequency"],
                )
              }
            >
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Select sync frequency" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="hourly">Every hour</SelectItem>
                <SelectItem value="daily">Once a day</SelectItem>
                <SelectItem value="weekly">Once a week</SelectItem>
                <SelectItem value="never">Manual sync only</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="enabled" className="text-right">
              Enabled
            </Label>
            <div className="flex items-center space-x-2 col-span-3">
              <Switch
                id="enabled"
                checked={source.enabled}
                onCheckedChange={(checked) => handleChange("enabled", checked)}
              />
              <Label htmlFor="enabled" className="cursor-pointer">
                {source.enabled ? "Active" : "Inactive"}
              </Label>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={!isValid}>
            Add Source
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AddSourceDialog;

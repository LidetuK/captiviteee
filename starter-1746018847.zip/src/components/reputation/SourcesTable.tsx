import { FC } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { ReviewSource } from "@/lib/reputation/reputationManager";
import { ExternalLink, RefreshCw, Settings, Trash2 } from "lucide-react";

interface SourcesTableProps {
  sources: ReviewSource[];
  onToggleSource?: (sourceId: string, enabled: boolean) => void;
  onDeleteSource?: (sourceId: string) => void;
  onEditSource?: (source: ReviewSource) => void;
  onSyncSource?: (sourceId: string) => void;
}

const SourcesTable: FC<SourcesTableProps> = ({
  sources = [],
  onToggleSource,
  onDeleteSource,
  onEditSource,
  onSyncSource,
}) => {
  const getSourceTypeIcon = (type: ReviewSource["type"]) => {
    // In a real app, you would use actual icons for each source type
    return (
      <Badge variant="outline" className="font-normal">
        {type}
      </Badge>
    );
  };

  const formatSyncFrequency = (frequency: ReviewSource["syncFrequency"]) => {
    switch (frequency) {
      case "hourly":
        return "Every hour";
      case "daily":
        return "Once a day";
      case "weekly":
        return "Once a week";
      case "never":
        return "Manual only";
      default:
        return frequency;
    }
  };

  return (
    <div className="bg-white rounded-md shadow">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Source Name</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Sync Frequency</TableHead>
              <TableHead>Last Synced</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sources.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={6}
                  className="text-center py-8 text-muted-foreground"
                >
                  No review sources configured. Add a source to start collecting
                  reviews.
                </TableCell>
              </TableRow>
            ) : (
              sources.map((source) => (
                <TableRow key={source.id}>
                  <TableCell className="font-medium">{source.name}</TableCell>
                  <TableCell>{getSourceTypeIcon(source.type)}</TableCell>
                  <TableCell>
                    {formatSyncFrequency(source.syncFrequency)}
                  </TableCell>
                  <TableCell>
                    {source.lastSyncTime
                      ? new Date(source.lastSyncTime).toLocaleString()
                      : "Never"}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={source.enabled}
                        onCheckedChange={(checked) =>
                          onToggleSource?.(source.id, checked)
                        }
                      />
                      <span
                        className={
                          source.enabled
                            ? "text-green-600"
                            : "text-muted-foreground"
                        }
                      >
                        {source.enabled ? "Active" : "Inactive"}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end space-x-2">
                      {source.url && (
                        <Button variant="ghost" size="icon" asChild>
                          <a
                            href={source.url}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onSyncSource?.(source.id)}
                        disabled={!source.enabled}
                      >
                        <RefreshCw className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onEditSource?.(source)}
                      >
                        <Settings className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onDeleteSource?.(source.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default SourcesTable;

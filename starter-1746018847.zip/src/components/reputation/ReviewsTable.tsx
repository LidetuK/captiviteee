import { FC, useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Review } from "@/lib/reputation/reputationManager";
import { MessageSquare, Star, Filter, Search } from "lucide-react";

interface ReviewsTableProps {
  reviews?: Review[];
  onRespondClick?: (review: Review) => void;
  onFilterChange?: (filters: ReviewFilters) => void;
}

export interface ReviewFilters {
  sourceId?: string;
  minRating?: number;
  maxRating?: number;
  status?: Review["status"];
  sentiment?: "positive" | "neutral" | "negative";
  hasResponse?: boolean;
  search?: string;
}

const ReviewsTable: FC<ReviewsTableProps> = ({
  reviews = [],
  onRespondClick,
  onFilterChange,
}) => {
  const [filters, setFilters] = useState<ReviewFilters>({});
  const [showFilters, setShowFilters] = useState(false);

  const handleFilterChange = (newFilters: Partial<ReviewFilters>) => {
    const updatedFilters = { ...filters, ...newFilters };
    setFilters(updatedFilters);
    onFilterChange?.(updatedFilters);
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFilterChange({ search: e.target.value });
  };

  const getStatusBadge = (status: Review["status"]) => {
    switch (status) {
      case "new":
        return <Badge variant="secondary">New</Badge>;
      case "read":
        return <Badge variant="outline">Read</Badge>;
      case "responded":
        return <Badge variant="success">Responded</Badge>;
      case "flagged":
        return <Badge variant="destructive">Flagged</Badge>;
      case "archived":
        return <Badge variant="default">Archived</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getSentimentBadge = (sentiment?: { score: number }) => {
    if (!sentiment) return null;

    if (sentiment.score > 0.2) {
      return <Badge className="bg-green-500">Positive</Badge>;
    } else if (sentiment.score < -0.2) {
      return <Badge className="bg-red-500">Negative</Badge>;
    } else {
      return <Badge className="bg-gray-500">Neutral</Badge>;
    }
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star
            key={i}
            size={16}
            className={
              i < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
            }
          />
        ))}
        <span className="ml-2 text-sm">{rating}</span>
      </div>
    );
  };

  return (
    <div className="bg-white rounded-md shadow">
      <div className="p-4 border-b flex justify-between items-center">
        <h3 className="text-lg font-medium">Customer Reviews</h3>
        <div className="flex space-x-2">
          <div className="relative w-64">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search reviews..."
              className="pl-8"
              value={filters.search || ""}
              onChange={handleSearchChange}
            />
          </div>
          <Button
            variant="outline"
            size="icon"
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {showFilters && (
        <div className="p-4 border-b grid grid-cols-1 md:grid-cols-4 gap-4">
          <Select
            value={filters.status}
            onValueChange={(value) =>
              handleFilterChange({ status: value as Review["status"] })
            }
          >
            <SelectTrigger>
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Statuses</SelectItem>
              <SelectItem value="new">New</SelectItem>
              <SelectItem value="read">Read</SelectItem>
              <SelectItem value="responded">Responded</SelectItem>
              <SelectItem value="flagged">Flagged</SelectItem>
              <SelectItem value="archived">Archived</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={filters.sentiment}
            onValueChange={(value) =>
              handleFilterChange({
                sentiment: value as "positive" | "neutral" | "negative",
              })
            }
          >
            <SelectTrigger>
              <SelectValue placeholder="Filter by sentiment" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Sentiments</SelectItem>
              <SelectItem value="positive">Positive</SelectItem>
              <SelectItem value="neutral">Neutral</SelectItem>
              <SelectItem value="negative">Negative</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={String(filters.minRating || "")}
            onValueChange={(value) =>
              handleFilterChange({
                minRating: value ? Number(value) : undefined,
              })
            }
          >
            <SelectTrigger>
              <SelectValue placeholder="Min rating" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">Any Rating</SelectItem>
              <SelectItem value="1">1+ Star</SelectItem>
              <SelectItem value="2">2+ Stars</SelectItem>
              <SelectItem value="3">3+ Stars</SelectItem>
              <SelectItem value="4">4+ Stars</SelectItem>
              <SelectItem value="5">5 Stars</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={String(
              filters.hasResponse === undefined ? "" : filters.hasResponse,
            )}
            onValueChange={(value) => {
              if (value === "") {
                handleFilterChange({ hasResponse: undefined });
              } else {
                handleFilterChange({ hasResponse: value === "true" });
              }
            }}
          >
            <SelectTrigger>
              <SelectValue placeholder="Response status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All</SelectItem>
              <SelectItem value="true">Has Response</SelectItem>
              <SelectItem value="false">Needs Response</SelectItem>
            </SelectContent>
          </Select>
        </div>
      )}

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Source</TableHead>
              <TableHead>Rating</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead className="w-[300px]">Review</TableHead>
              <TableHead>Sentiment</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {reviews.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={8}
                  className="text-center py-8 text-muted-foreground"
                >
                  No reviews found. Try adjusting your filters.
                </TableCell>
              </TableRow>
            ) : (
              reviews.map((review) => (
                <TableRow key={review.id}>
                  <TableCell>
                    <Badge variant="outline">{review.sourceName}</Badge>
                  </TableCell>
                  <TableCell>{renderStars(review.rating)}</TableCell>
                  <TableCell>
                    <div className="font-medium">{review.authorName}</div>
                  </TableCell>
                  <TableCell>
                    {review.title && (
                      <div className="font-medium">{review.title}</div>
                    )}
                    <div className="text-sm text-muted-foreground line-clamp-2">
                      {review.content}
                    </div>
                  </TableCell>
                  <TableCell>{getSentimentBadge(review.sentiment)}</TableCell>
                  <TableCell>{getStatusBadge(review.status)}</TableCell>
                  <TableCell>
                    {new Date(review.publishedAt).toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onRespondClick?.(review)}
                      disabled={review.status === "responded"}
                    >
                      <MessageSquare className="h-4 w-4 mr-2" />
                      {review.status === "responded" ? "View" : "Respond"}
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default ReviewsTable;

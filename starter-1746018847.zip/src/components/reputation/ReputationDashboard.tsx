import { FC, useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Review,
  ReviewSource,
  ReputationMetrics,
} from "@/lib/reputation/reputationManager";
import {
  Star,
  TrendingUp,
  MessageSquare,
  AlertTriangle,
  BarChart3,
  RefreshCw,
} from "lucide-react";
import ReviewsTable, { ReviewFilters } from "./ReviewsTable";
import ReviewResponseDialog from "./ReviewResponseDialog";
import SourcesTable from "./SourcesTable";
import AddSourceDialog from "./AddSourceDialog";

interface ReputationDashboardProps {
  reputationManager: any; // Using any for now, should be properly typed
}

const ReputationDashboard: FC<ReputationDashboardProps> = ({
  reputationManager,
}) => {
  const [activeTab, setActiveTab] = useState("overview");
  const [reviews, setReviews] = useState<Review[]>([]);
  const [sources, setSources] = useState<ReviewSource[]>([]);
  const [metrics, setMetrics] = useState<ReputationMetrics | null>(null);
  const [filters, setFilters] = useState<ReviewFilters>({});
  const [selectedReview, setSelectedReview] = useState<Review | undefined>();
  const [responseDialogOpen, setResponseDialogOpen] = useState(false);
  const [addSourceDialogOpen, setAddSourceDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch data
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      try {
        // In a real implementation, these would be API calls
        const allSources = reputationManager.getAllSources();
        setSources(allSources);

        const filteredReviews = reputationManager.getReviews(filters);
        setReviews(filteredReviews);

        // For demo purposes, create a metrics object
        if (filteredReviews.length > 0) {
          const now = new Date();
          const lastMonth = new Date();
          lastMonth.setMonth(lastMonth.getMonth() - 1);

          const aggregatedMetrics = reputationManager.aggregateMetrics
            ? reputationManager.aggregateMetrics(filteredReviews)
            : {
                averageRating: 0,
                totalReviews: 0,
                sentimentScore: 0,
                responseRate: 0,
                sourcesBreakdown: {},
              };

          const demoMetrics: ReputationMetrics = {
            id: "current",
            period: "monthly",
            startDate: lastMonth,
            endDate: now,
            metrics: {
              averageRating: aggregatedMetrics.averageRating || 0,
              totalReviews: aggregatedMetrics.totalReviews || 0,
              reviewsBySource: aggregatedMetrics.sourcesBreakdown || {},
              reviewsByRating: {
                "1": filteredReviews.filter((r) => r.rating === 1).length,
                "2": filteredReviews.filter((r) => r.rating === 2).length,
                "3": filteredReviews.filter((r) => r.rating === 3).length,
                "4": filteredReviews.filter((r) => r.rating === 4).length,
                "5": filteredReviews.filter((r) => r.rating === 5).length,
              },
              responseRate: aggregatedMetrics.responseRate / 100 || 0,
              averageResponseTime: 24, // Mock value
              sentimentScore: aggregatedMetrics.sentimentScore || 0,
              topKeywords: [],
              ratingTrend: [],
              volumeTrend: [],
            },
          };

          setMetrics(demoMetrics);
        }
      } catch (error) {
        console.error("Error loading reputation data:", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [reputationManager, filters]);

  const handleFilterChange = (newFilters: ReviewFilters) => {
    setFilters(newFilters);
  };

  const handleRespondClick = (review: Review) => {
    setSelectedReview(review);
    setResponseDialogOpen(true);
  };

  const handleResponseSubmit = async (
    reviewId: string,
    content: string,
    status: string,
  ) => {
    try {
      // In a real implementation, this would be an API call
      await reputationManager.createResponse({
        reviewId,
        content,
        status,
        createdBy: "current-user", // This would come from auth context
      });

      // Refresh reviews
      const updatedReviews = reputationManager.getReviews(filters);
      setReviews(updatedReviews);
    } catch (error) {
      console.error("Error submitting response:", error);
    }
  };

  const handleAddSource = async (
    source: Omit<ReviewSource, "id" | "lastSyncTime">,
  ) => {
    try {
      // Generate a unique ID
      const sourceWithId = {
        ...source,
        id: `source_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      };

      // In a real implementation, this would be an API call
      await reputationManager.addSource(sourceWithId);

      // Refresh sources
      const updatedSources = reputationManager.getAllSources();
      setSources(updatedSources);

      setAddSourceDialogOpen(false);
    } catch (error) {
      console.error("Error adding source:", error);
    }
  };

  const renderOverviewCards = () => {
    if (!metrics) return null;

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Average Rating
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Star className="h-5 w-5 text-yellow-400 fill-yellow-400 mr-2" />
              <div className="text-2xl font-bold">
                {metrics.metrics.averageRating.toFixed(1)}
              </div>
              <div className="text-sm text-muted-foreground ml-2">/5</div>
            </div>
            <div className="mt-2">
              <Progress
                value={metrics.metrics.averageRating * 20}
                className="h-2"
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Reviews
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <MessageSquare className="h-5 w-5 text-blue-500 mr-2" />
              <div className="text-2xl font-bold">
                {metrics.metrics.totalReviews}
              </div>
            </div>
            <div className="text-xs text-muted-foreground mt-2">
              <TrendingUp className="h-3 w-3 inline mr-1" />
              <span className="text-green-500 font-medium">+12%</span> from last
              month
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Response Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <div className="text-2xl font-bold">
                {(metrics.metrics.responseRate * 100).toFixed(0)}%
              </div>
            </div>
            <div className="mt-2">
              <Progress
                value={metrics.metrics.responseRate * 100}
                className="h-2"
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Needs Attention
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <AlertTriangle className="h-5 w-5 text-amber-500 mr-2" />
              <div className="text-2xl font-bold">
                {reviews.filter((r) => r.status === "flagged").length}
              </div>
            </div>
            <div className="text-xs text-muted-foreground mt-2">
              Negative reviews requiring immediate response
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold tracking-tight">
          Reputation Management
        </h2>
        <Button variant="outline" size="sm" disabled={isLoading}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh Data
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 lg:w-auto lg:grid-cols-none lg:flex">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="reviews">Reviews</TabsTrigger>
          <TabsTrigger value="sources">Sources</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {isLoading ? (
            <div className="flex justify-center items-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <>
              {renderOverviewCards()}

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle>Recent Reviews</CardTitle>
                    <CardDescription>
                      Your most recent customer feedback across all platforms
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ReviewsTable
                      reviews={reviews.slice(0, 5)}
                      onRespondClick={handleRespondClick}
                    />
                    <div className="mt-4 text-center">
                      <Button
                        variant="link"
                        onClick={() => setActiveTab("reviews")}
                      >
                        View all reviews
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Rating Distribution</CardTitle>
                    <CardDescription>
                      Breakdown of ratings across all platforms
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {metrics && (
                      <div className="space-y-4">
                        {[5, 4, 3, 2, 1].map((rating) => {
                          const count =
                            metrics.metrics.reviewsByRating[
                              rating.toString()
                            ] || 0;
                          const percentage = metrics.metrics.totalReviews
                            ? (count / metrics.metrics.totalReviews) * 100
                            : 0;

                          return (
                            <div key={rating} className="space-y-1">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center">
                                  <span className="font-medium mr-2">
                                    {rating}
                                  </span>
                                  <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                                </div>
                                <span className="text-sm text-muted-foreground">
                                  {count} ({percentage.toFixed(0)}%)
                                </span>
                              </div>
                              <Progress value={percentage} className="h-2" />
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </>
          )}
        </TabsContent>

        <TabsContent value="reviews">
          {isLoading ? (
            <div className="flex justify-center items-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <ReviewsTable
              reviews={reviews}
              onRespondClick={handleRespondClick}
              onFilterChange={handleFilterChange}
            />
          )}
        </TabsContent>

        <TabsContent value="sources">
          {isLoading ? (
            <div className="flex justify-center items-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <>
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium">Review Sources</h3>
                <Button onClick={() => setAddSourceDialogOpen(true)}>
                  Add Source
                </Button>
              </div>
              <SourcesTable sources={sources} />
            </>
          )}
        </TabsContent>
      </Tabs>

      <ReviewResponseDialog
        review={selectedReview}
        open={responseDialogOpen}
        onOpenChange={setResponseDialogOpen}
        onSubmit={handleResponseSubmit}
        templates={[]} // In a real app, these would come from the API
      />

      <AddSourceDialog
        open={addSourceDialogOpen}
        onOpenChange={setAddSourceDialogOpen}
        onSubmit={handleAddSource}
      />
    </div>
  );
};

export default ReputationDashboard;

import React, { useState, useEffect, useMemo } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

import { phoneAgent } from "@/lib/ai/voice/phoneAgent";
import { callMonitor } from "@/lib/ai/voice/callMonitor";
import { callAuditor } from "@/lib/ai/voice/callAuditor";

import {
  AlertCircle,
  BarChart2,
  BookOpen,
  Bot,
  Calendar,
  CheckCircle,
  ChevronDown,
  Clock,
  Copy,
  Download,
  FileText,
  Filter,
  HelpCircle,
  History,
  Info,
  LayoutDashboard,
  MessageSquare,
  Mic,
  Phone,
  PhoneCall,
  PhoneForwarded,
  PhoneIncoming,
  PhoneOff,
  PhoneOutgoing,
  Play,
  Plus,
  RefreshCw,
  Save,
  Search,
  Settings,
  Share2,
  Star,
  Trash2,
  Upload,
  User,
  Users,
  Volume2,
  Wand2,
  XCircle,
} from "lucide-react";

export const PhoneAgentDashboard = () => {
  const [activeTab, setActiveTab] = useState("agents");
  const [agents, setAgents] = useState([]);
  const [monitors, setMonitors] = useState([]);
  const [activeCalls, setActiveCalls] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [batches, setBatches] = useState([]);
  const [batchProgress, setBatchProgress] = useState({});
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [showOnboarding, setShowOnboarding] = useState(true);
  const [showTemplateDialog, setShowTemplateDialog] = useState(false);
  const [showHelpDialog, setShowHelpDialog] = useState(false);
  const [showVoiceTestDialog, setShowVoiceTestDialog] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState(null);

  const [selectedAgent, setSelectedAgent] = useState(null);
  const [selectedCall, setSelectedCall] = useState(null);
  const [selectedBatch, setSelectedBatch] = useState(null);

  const [showNewAgentDialog, setShowNewAgentDialog] = useState(false);
  const [showNewBatchDialog, setShowNewBatchDialog] = useState(false);
  const [showCallDialog, setShowCallDialog] = useState(false);

  const [newAgentName, setNewAgentName] = useState("");
  const [newAgentVoice, setNewAgentVoice] = useState("female");
  const [newAgentTone, setNewAgentTone] = useState("professional");

  const [newCallerId, setNewCallerId] = useState("");

  const [newBatchName, setNewBatchName] = useState("");
  const [newBatchCallerIds, setNewBatchCallerIds] = useState("");
  const [newBatchAgentId, setNewBatchAgentId] = useState("");
  const [newBatchConcurrent, setNewBatchConcurrent] = useState(1);

  // Load data on component mount
  useEffect(() => {
    loadData();

    // Set up polling for active calls and alerts
    const interval = setInterval(() => {
      refreshActiveCalls();
      refreshAlerts();
      refreshBatches();
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const loadData = () => {
    setAgents(phoneAgent.getAllAgents());
    setMonitors(callMonitor.getAllMonitors());
    refreshActiveCalls();
    refreshAlerts();
    refreshBatches();
  };

  const refreshActiveCalls = () => {
    setActiveCalls(phoneAgent.getAllActiveCalls());
  };

  const refreshAlerts = () => {
    setAlerts(callMonitor.getActiveAlerts());
  };

  const refreshBatches = () => {
    // Mock implementation since batchCaller is not fully implemented
    setBatches([]);
    setBatchProgress({});
  };

  const handleCreateAgent = async () => {
    if (!newAgentName) return;

    try {
      const agentId = `agent_${Date.now()}`;
      const newAgent = {
        id: agentId,
        name: newAgentName,
        voice: {
          gender: newAgentVoice,
          pitch: 1.0,
          rate: 1.0,
        },
        personality: {
          tone: newAgentTone,
          pace: "medium",
          vocabulary: "standard",
        },
        compliance: {
          recordingDisclosure: true,
          dataPrivacyStatements: [
            "Your data is protected according to our privacy policy.",
          ],
          requiredDisclosures: [
            "This call may be recorded for quality and training purposes.",
          ],
          prohibitedPhrases: ["guarantee", "promise", "100%"],
          sensitiveTopics: ["political", "religious"],
        },
        filtering: {
          inputFilters: [],
          outputFilters: [],
          realTimeFiltering: true,
          sensitivityLevel: 0.7,
        },
        capabilities: {
          languages: ["en"],
          canTransferToHuman: true,
          canSendSMS: false,
          canSendEmail: false,
          canScheduleCallback: true,
          canProcessPayments: false,
        },
        metrics: {
          trackCallDuration: true,
          trackSentiment: true,
          trackResolution: true,
          trackTransferRate: true,
        },
      };

      await phoneAgent.createAgent(newAgent);
      setAgents(phoneAgent.getAllAgents());
      setShowNewAgentDialog(false);
      setNewAgentName("");
      setNewAgentVoice("female");
      setNewAgentTone("professional");
    } catch (error) {
      console.error("Error creating agent:", error);
    }
  };

  const handleStartCall = async () => {
    if (!selectedAgent || !newCallerId) return;

    try {
      const callSession = await phoneAgent.startCall(
        selectedAgent.id,
        newCallerId,
      );
      if (callSession) {
        refreshActiveCalls();
        setShowCallDialog(false);
        setNewCallerId("");
        setSelectedCall(callSession);
        setActiveTab("calls");
      }
    } catch (error) {
      console.error("Error starting call:", error);
    }
  };

  const handleEndCall = async (callId) => {
    try {
      await phoneAgent.endCall(callId);
      refreshActiveCalls();
      if (selectedCall?.id === callId) {
        setSelectedCall(null);
      }
    } catch (error) {
      console.error("Error ending call:", error);
    }
  };

  const handleCreateBatch = async () => {
    // Mock implementation
    setShowNewBatchDialog(false);
    setNewBatchName("");
    setNewBatchCallerIds("");
    setNewBatchAgentId("");
    setNewBatchConcurrent(1);
  };

  const handleStartBatch = async (batchId) => {
    // Mock implementation
  };

  const handleCancelBatch = async (batchId) => {
    // Mock implementation
  };

  const handleAcknowledgeAlert = async (alertId) => {
    try {
      await callMonitor.acknowledgeAlert(alertId, "user");
      refreshAlerts();
    } catch (error) {
      console.error("Error acknowledging alert:", error);
    }
  };

  const handleResolveAlert = async (alertId) => {
    try {
      await callMonitor.resolveAlert(alertId, "user");
      refreshAlerts();
    } catch (error) {
      console.error("Error resolving alert:", error);
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500">Active</Badge>;
      case "completed":
        return <Badge className="bg-blue-500">Completed</Badge>;
      case "transferred":
        return <Badge className="bg-yellow-500">Transferred</Badge>;
      case "dropped":
        return <Badge className="bg-red-500">Dropped</Badge>;
      case "pending":
        return <Badge className="bg-gray-500">Pending</Badge>;
      case "in_progress":
        return <Badge className="bg-green-500">In Progress</Badge>;
      case "cancelled":
        return <Badge className="bg-orange-500">Cancelled</Badge>;
      case "failed":
        return <Badge className="bg-red-500">Failed</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getSeverityBadge = (severity) => {
    switch (severity) {
      case "low":
        return <Badge className="bg-blue-500">Low</Badge>;
      case "medium":
        return <Badge className="bg-yellow-500">Medium</Badge>;
      case "high":
        return <Badge className="bg-orange-500">High</Badge>;
      case "critical":
        return <Badge className="bg-red-500">Critical</Badge>;
      default:
        return <Badge>{severity}</Badge>;
    }
  };

  const formatDuration = (seconds) => {
    if (seconds === undefined) return "--:--";
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  // Filter agents based on search query
  const filteredAgents = useMemo(() => {
    if (!searchQuery) return agents;
    return agents.filter((agent) =>
      agent.name.toLowerCase().includes(searchQuery.toLowerCase()),
    );
  }, [agents, searchQuery]);

  // Filter calls based on status and search
  const filteredCalls = useMemo(() => {
    let filtered = activeCalls;
    if (filterStatus !== "all") {
      filtered = filtered.filter((call) => call.status === filterStatus);
    }
    if (searchQuery) {
      filtered = filtered.filter(
        (call) =>
          call.id.includes(searchQuery) ||
          call.callerId.toLowerCase().includes(searchQuery.toLowerCase()),
      );
    }
    return filtered;
  }, [activeCalls, filterStatus, searchQuery]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await loadData();
    setTimeout(() => setIsRefreshing(false), 800);
  };

  /* Handle copying call ID to clipboard */
  function handleCopyCallId(callId: string): void {
    navigator.clipboard.writeText(callId);
    // Could add toast notification here
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex flex-col gap-4 mb-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-bold">AI Phone Agent Dashboard</h1>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="rounded-full"
                    onClick={() => setShowHelpDialog(true)}
                  >
                    <HelpCircle className="h-5 w-5 text-muted-foreground" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Get help with the Phone Agent Dashboard</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={handleRefresh}
              className={isRefreshing ? "animate-spin" : ""}
            >
              <RefreshCw className="h-4 w-4" />
            </Button>
            {activeTab === "agents" && (
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setShowTemplateDialog(true)}
                >
                  <Wand2 className="mr-2 h-4 w-4" /> Templates
                </Button>
                <Button onClick={() => setShowNewAgentDialog(true)}>
                  <Plus className="mr-2 h-4 w-4" /> New Agent
                </Button>
              </div>
            )}
            {activeTab === "batches" && (
              <Button onClick={() => setShowNewBatchDialog(true)}>
                <Plus className="mr-2 h-4 w-4" /> New Batch
              </Button>
            )}
            {selectedAgent && activeTab === "agents" && (
              <Button
                onClick={() => {
                  setShowCallDialog(true);
                  setNewCallerId("");
                }}
              >
                <PhoneCall className="mr-2 h-4 w-4" /> Start Call
              </Button>
            )}
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={`Search ${activeTab === "agents" ? "agents" : activeTab === "calls" ? "calls" : "..."}`}
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          {activeTab === "calls" && (
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="transferred">Transferred</SelectItem>
                <SelectItem value="dropped">Dropped</SelectItem>
              </SelectContent>
            </Select>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <Card className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-16 h-16 bg-primary/10 rounded-bl-full flex items-center justify-center">
            <Users className="h-6 w-6 text-primary absolute top-3 right-3" />
          </div>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Agents</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{agents.length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              +{Math.floor(Math.random() * 5)} this week
            </p>
          </CardContent>
        </Card>
        <Card className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-16 h-16 bg-green-500/10 rounded-bl-full flex items-center justify-center">
            <PhoneIncoming className="h-6 w-6 text-green-500 absolute top-3 right-3" />
          </div>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active Calls</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeCalls.length}</div>
            <div className="flex items-center gap-1 mt-1">
              <span className="text-xs text-muted-foreground">
                Avg. duration:
              </span>
              <span className="text-xs font-medium">3:24</span>
            </div>
          </CardContent>
        </Card>
        <Card className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-16 h-16 bg-yellow-500/10 rounded-bl-full flex items-center justify-center">
            <AlertCircle className="h-6 w-6 text-yellow-500 absolute top-3 right-3" />
          </div>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{alerts.length}</div>
            {alerts.length > 0 && (
              <div className="flex items-center gap-1 mt-1">
                <span className="text-xs text-red-500 font-medium">
                  {alerts.filter((a) => a.severity === "critical").length}{" "}
                  critical
                </span>
              </div>
            )}
          </CardContent>
        </Card>
        <Card className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-16 h-16 bg-blue-500/10 rounded-bl-full flex items-center justify-center">
            <BarChart2 className="h-6 w-6 text-blue-500 absolute top-3 right-3" />
          </div>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">
              Active Batches
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {batches.filter((b) => b.status === "in_progress").length}
            </div>
            <div className="flex items-center gap-1 mt-1">
              <span className="text-xs text-muted-foreground">Completion:</span>
              <span className="text-xs font-medium">68%</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6 w-full">
          <TabsTrigger value="agents" className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            <span>Agents</span>
            <Badge variant="outline" className="ml-1">
              {agents.length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger value="calls" className="flex items-center gap-1">
            <PhoneCall className="h-4 w-4" />
            <span>Active Calls</span>
            <Badge variant="outline" className="ml-1">
              {activeCalls.length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger value="alerts" className="flex items-center gap-1">
            <AlertCircle className="h-4 w-4" />
            <span>Alerts</span>
            <Badge variant="outline" className="ml-1">
              {alerts.length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger value="batches" className="flex items-center gap-1">
            <LayoutDashboard className="h-4 w-4" />
            <span>Batch Calls</span>
            <Badge variant="outline" className="ml-1">
              {batches.filter((b) => b.status === "in_progress").length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger value="history" className="flex items-center gap-1">
            <History className="h-4 w-4" />
            <span>Call History</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="agents">
          {showOnboarding && agents.length === 0 ? (
            <Card className="mb-6 border-dashed">
              <CardHeader>
                <CardTitle>Welcome to AI Phone Agent</CardTitle>
                <CardDescription>
                  Create your first AI phone agent to start handling calls
                  automatically.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex flex-col items-center text-center p-4 bg-muted/50 rounded-lg">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center mb-3">
                      <Wand2 className="h-5 w-5 text-primary" />
                    </div>
                    <h3 className="font-medium mb-1">Use Templates</h3>
                    <p className="text-sm text-muted-foreground">
                      Start with pre-configured agent templates for different
                      industries
                    </p>
                    <Button
                      variant="link"
                      onClick={() => setShowTemplateDialog(true)}
                      className="mt-2"
                    >
                      Browse Templates
                    </Button>
                  </div>
                  <div className="flex flex-col items-center text-center p-4 bg-primary/5 rounded-lg">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center mb-3">
                      <Plus className="h-5 w-5 text-primary" />
                    </div>
                    <h3 className="font-medium mb-1">Create Custom Agent</h3>
                    <p className="text-sm text-muted-foreground">
                      Build a new agent from scratch with custom personality and
                      capabilities
                    </p>
                    <Button
                      variant="link"
                      onClick={() => setShowNewAgentDialog(true)}
                      className="mt-2"
                    >
                      Create Agent
                    </Button>
                  </div>
                  <div className="flex flex-col items-center text-center p-4 bg-muted/50 rounded-lg">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center mb-3">
                      <BookOpen className="h-5 w-5 text-primary" />
                    </div>
                    <h3 className="font-medium mb-1">Learn More</h3>
                    <p className="text-sm text-muted-foreground">
                      Explore documentation and best practices for AI phone
                      agents
                    </p>
                    <Button
                      variant="link"
                      onClick={() => setShowHelpDialog(true)}
                      className="mt-2"
                    >
                      View Guide
                    </Button>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowOnboarding(false)}
                >
                  Dismiss
                </Button>
              </CardFooter>
            </Card>
          ) : null}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAgents.map((agent) => (
              <Card
                key={agent.id}
                className={`cursor-pointer hover:shadow-md transition-shadow ${selectedAgent?.id === agent.id ? "ring-2 ring-primary" : ""}`}
                onClick={() => setSelectedAgent(agent)}
              >
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>{agent.name}</CardTitle>
                      <CardDescription>
                        {agent.voice.gender} voice • {agent.personality.tone}{" "}
                        tone
                      </CardDescription>
                    </div>
                    <div className="flex items-center">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={(e) => {
                                e.stopPropagation();
                                setShowVoiceTestDialog(true);
                              }}
                            >
                              <Volume2 className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Test voice</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="bg-primary/5">
                        {agent.capabilities.languages.join(", ")}
                      </Badge>
                      {agent.capabilities.canTransferToHuman && (
                        <Badge
                          variant="outline"
                          className="bg-green-500/5 text-green-500 border-green-200"
                        >
                          Human Transfer
                        </Badge>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="flex items-center gap-1">
                        <Mic className="h-3.5 w-3.5 text-muted-foreground" />
                        <span>Voice:</span>
                      </div>
                      <div className="font-medium">{agent.voice.gender}</div>

                      <div className="flex items-center gap-1">
                        <Users className="h-3.5 w-3.5 text-muted-foreground" />
                        <span>Personality:</span>
                      </div>
                      <div className="font-medium capitalize">
                        {agent.personality.tone}
                      </div>

                      <div className="flex items-center gap-1">
                        <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                        <span>Scheduling:</span>
                      </div>
                      <div className="font-medium">
                        {agent.capabilities.canScheduleCallback
                          ? "Enabled"
                          : "Disabled"}
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between border-t pt-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedAgent(agent);
                      setShowCallDialog(true);
                    }}
                  >
                    <PhoneCall className="mr-2 h-4 w-4" /> Start Call
                  </Button>
                  <div className="flex gap-1">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={(e) => {
                              e.stopPropagation();
                              // Duplicate agent (not implemented)
                            }}
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Duplicate agent</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <Settings className="h-4 w-4" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent
                        className="w-56"
                        align="end"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="grid gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="justify-start"
                          >
                            <Settings className="mr-2 h-4 w-4" /> Edit Agent
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="justify-start"
                          >
                            <Share2 className="mr-2 h-4 w-4" /> Share Agent
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="justify-start text-red-500 hover:text-red-500"
                          >
                            <Trash2 className="mr-2 h-4 w-4" /> Delete Agent
                          </Button>
                        </div>
                      </PopoverContent>
                    </Popover>
                  </div>
                </CardFooter>
              </Card>
            ))}

            {/* Add New Agent Card */}
            <Card
              className="cursor-pointer border-dashed hover:border-primary/50 hover:bg-primary/5 transition-colors flex flex-col items-center justify-center py-8"
              onClick={() => setShowNewAgentDialog(true)}
            >
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Plus className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-medium mb-1">Create New Agent</h3>
              <p className="text-sm text-muted-foreground text-center max-w-[200px]">
                Build a custom AI phone agent with your desired personality and
                capabilities
              </p>
            </Card>

            {filteredAgents.length === 0 && agents.length > 0 && (
              <div className="col-span-3 text-center py-12">
                <p className="text-muted-foreground">
                  No agents match your search. Try a different search term.
                </p>
              </div>
            )}

            {agents.length === 0 && !showOnboarding && (
              <div className="col-span-3 text-center py-12">
                <p className="text-muted-foreground">
                  No agents created yet. Create your first agent to get started.
                </p>
              </div>
            )}
          </div>

          {selectedAgent && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>{selectedAgent.name} Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">
                      Voice Configuration
                    </h3>
                    <div className="space-y-4">
                      <div className="grid grid-cols-3 gap-4 items-center">
                        <Label>Gender:</Label>
                        <div className="col-span-2">
                          {selectedAgent.voice.gender}
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-4 items-center">
                        <Label>Pitch:</Label>
                        <div className="col-span-2">
                          <Slider
                            value={[selectedAgent.voice.pitch * 50]}
                            max={100}
                            step={1}
                            disabled
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-4 items-center">
                        <Label>Rate:</Label>
                        <div className="col-span-2">
                          <Slider
                            value={[selectedAgent.voice.rate * 50]}
                            max={100}
                            step={1}
                            disabled
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Personality</h3>
                    <div className="space-y-4">
                      <div className="grid grid-cols-3 gap-4 items-center">
                        <Label>Tone:</Label>
                        <div className="col-span-2">
                          {selectedAgent.personality.tone}
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-4 items-center">
                        <Label>Pace:</Label>
                        <div className="col-span-2">
                          {selectedAgent.personality.pace}
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-4 items-center">
                        <Label>Vocabulary:</Label>
                        <div className="col-span-2">
                          {selectedAgent.personality.vocabulary}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6">
                  <h3 className="text-lg font-medium mb-2">Compliance</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={selectedAgent.compliance.recordingDisclosure}
                        disabled
                      />
                      <Label>Recording Disclosure</Label>
                    </div>

                    <div>
                      <Label>Required Disclosures:</Label>
                      <ul className="list-disc list-inside mt-2">
                        {selectedAgent.compliance.requiredDisclosures.map(
                          (disclosure, index) => (
                            <li key={index} className="text-sm">
                              {disclosure}
                            </li>
                          ),
                        )}
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="mt-6">
                  <h3 className="text-lg font-medium mb-2">Capabilities</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={selectedAgent.capabilities.canTransferToHuman}
                        disabled
                      />
                      <Label>Transfer to Human</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={selectedAgent.capabilities.canSendSMS}
                        disabled
                      />
                      <Label>Send SMS</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={selectedAgent.capabilities.canSendEmail}
                        disabled
                      />
                      <Label>Send Email</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={selectedAgent.capabilities.canScheduleCallback}
                        disabled
                      />
                      <Label>Schedule Callback</Label>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="calls">
          <div className="grid grid-cols-1 gap-6">
            {filteredCalls.length > 0 ? (
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-center">
                    <CardTitle>Active Calls</CardTitle>
                    <div className="flex items-center gap-2">
                      <Badge
                        variant="outline"
                        className="bg-green-500/10 text-green-500"
                      >
                        {
                          filteredCalls.filter((c) => c.status === "active")
                            .length
                        }{" "}
                        Active
                      </Badge>
                      <Badge
                        variant="outline"
                        className="bg-blue-500/10 text-blue-500"
                      >
                        {
                          filteredCalls.filter((c) => c.status === "completed")
                            .length
                        }{" "}
                        Completed
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Call ID</TableHead>
                        <TableHead>Agent</TableHead>
                        <TableHead>Caller</TableHead>
                        <TableHead>Duration</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Sentiment</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredCalls.map((call) => {
                        const agent = agents.find((a) => a.id === call.agentId);
                        return (
                          <TableRow
                            key={call.id}
                            className={`cursor-pointer hover:bg-muted/50 ${selectedCall?.id === call.id ? "bg-muted" : ""}`}
                            onClick={() => setSelectedCall(call)}
                          >
                            <TableCell className="font-medium">
                              <div className="flex items-center gap-1">
                                {call.id.substring(0, 8)}...
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        className="h-6 w-6"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handleCopyCallId(call.id);
                                        }}
                                      >
                                        <Copy className="h-3 w-3" />
                                      </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p>Copy call ID</p>
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center">
                                  <Users className="h-3 w-3 text-primary" />
                                </div>
                                {agent?.name || call.agentId}
                              </div>
                            </TableCell>
                            <TableCell>{call.callerId}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                                {formatDuration(call.duration)}
                              </div>
                            </TableCell>
                            <TableCell>{getStatusBadge(call.status)}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <div
                                  className="w-2 h-6 rounded-sm mr-1"
                                  style={{
                                    backgroundColor:
                                      call.metrics.averageSentiment > 0.2
                                        ? "#22c55e"
                                        : call.metrics.averageSentiment < -0.2
                                          ? "#ef4444"
                                          : "#9ca3af",
                                  }}
                                />
                                <div className="flex flex-col">
                                  <span className="text-sm">
                                    {call.metrics.averageSentiment.toFixed(2)}
                                  </span>
                                  <span className="text-xs text-muted-foreground">
                                    {call.metrics.averageSentiment > 0.2
                                      ? "Positive"
                                      : call.metrics.averageSentiment < -0.2
                                        ? "Negative"
                                        : "Neutral"}
                                  </span>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-1">
                                {call.status === "active" ? (
                                  <>
                                    <TooltipProvider>
                                      <Tooltip>
                                        <TooltipTrigger asChild>
                                          <Button
                                            variant="ghost"
                                            size="icon"
                                            className="h-8 w-8"
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              // Listen to call (not implemented)
                                            }}
                                          >
                                            <Volume2 className="h-4 w-4" />
                                          </Button>
                                        </TooltipTrigger>
                                        <TooltipContent>
                                          <p>Listen to call</p>
                                        </TooltipContent>
                                      </Tooltip>
                                    </TooltipProvider>
                                    <TooltipProvider>
                                      <Tooltip>
                                        <TooltipTrigger asChild>
                                          <Button
                                            variant="ghost"
                                            size="icon"
                                            className="h-8 w-8"
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              // Transfer call (not implemented)
                                            }}
                                          >
                                            <PhoneForwarded className="h-4 w-4" />
                                          </Button>
                                        </TooltipTrigger>
                                        <TooltipContent>
                                          <p>Transfer call</p>
                                        </TooltipContent>
                                      </Tooltip>
                                    </TooltipProvider>
                                    <TooltipProvider>
                                      <Tooltip>
                                        <TooltipTrigger asChild>
                                          <Button
                                            variant="ghost"
                                            size="icon"
                                            className="h-8 w-8 text-red-500 hover:text-red-500 hover:bg-red-50"
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              handleEndCall(call.id);
                                            }}
                                          >
                                            <PhoneOff className="h-4 w-4" />
                                          </Button>
                                        </TooltipTrigger>
                                        <TooltipContent>
                                          <p>End call</p>
                                        </TooltipContent>
                                      </Tooltip>
                                    </TooltipProvider>
                                  </>
                                ) : (
                                  <>
                                    <TooltipProvider>
                                      <Tooltip>
                                        <TooltipTrigger asChild>
                                          <Button
                                            variant="ghost"
                                            size="icon"
                                            className="h-8 w-8"
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              // Download transcript (not implemented)
                                            }}
                                          >
                                            <Download className="h-4 w-4" />
                                          </Button>
                                        </TooltipTrigger>
                                        <TooltipContent>
                                          <p>Download transcript</p>
                                        </TooltipContent>
                                      </Tooltip>
                                    </TooltipProvider>
                                  </>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            ) : (
              <div className="text-center py-12 bg-muted/20 rounded-lg border border-dashed flex flex-col items-center justify-center gap-3 p-8">
                <div className="w-12 h-12 rounded-full bg-muted/50 flex items-center justify-center">
                  <PhoneCall className="h-6 w-6 text-muted-foreground" />
                </div>
                <h3 className="font-medium">No active calls</h3>
                <p className="text-muted-foreground max-w-md">
                  {searchQuery
                    ? "No calls match your search criteria. Try a different search term."
                    : "Start a call with an agent to see it here. You can make test calls or set up batch calling for multiple simultaneous calls."}
                </p>
                {!searchQuery && (
                  <Button
                    variant="outline"
                    className="mt-2"
                    onClick={() => {
                      if (agents.length > 0) {
                        setSelectedAgent(agents[0]);
                        setShowCallDialog(true);
                      } else {
                        setShowNewAgentDialog(true);
                      }
                    }}
                  >
                    <PhoneCall className="mr-2 h-4 w-4" />{" "}
                    {agents.length > 0
                      ? "Start Test Call"
                      : "Create Agent First"}
                  </Button>
                )}
              </div>
            )}
          </div>

          {selectedCall && (
            <Card className="mt-6">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      Call Transcript
                      <Badge variant="outline" className="ml-1">
                        {selectedCall.transcript.length} messages
                      </Badge>
                    </CardTitle>
                    <CardDescription className="flex flex-wrap items-center gap-2 mt-1">
                      <div className="flex items-center gap-1">
                        <FileText className="h-3.5 w-3.5" />
                        <span>ID: {selectedCall.id.substring(0, 8)}...</span>
                      </div>
                      <span>•</span>
                      <div>{getStatusBadge(selectedCall.status)}</div>
                      <span>•</span>
                      <div className="flex items-center gap-1">
                        <Clock className="h-3.5 w-3.5" />
                        <span>{formatDuration(selectedCall.duration)}</span>
                      </div>
                    </CardDescription>
                  </div>
                  <div className="flex gap-1">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button variant="outline" size="sm">
                            <Download className="mr-2 h-4 w-4" /> Export
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Export transcript</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <Card className="bg-muted/30">
                    <CardHeader className="py-3">
                      <CardTitle className="text-sm flex items-center gap-1">
                        <Users className="h-4 w-4" /> Participants
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="py-0">
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                            <Bot className="h-4 w-4 text-primary" />
                          </div>
                          <div>
                            <div className="font-medium text-sm">
                              {agents.find((a) => a.id === selectedCall.agentId)
                                ?.name || "AI Agent"}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              Agent
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full bg-secondary/10 flex items-center justify-center">
                            <User className="h-4 w-4 text-secondary-foreground" />
                          </div>
                          <div>
                            <div className="font-medium text-sm">
                              {selectedCall.callerId}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              Caller
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-muted/30">
                    <CardHeader className="py-3">
                      <CardTitle className="text-sm flex items-center gap-1">
                        <BarChart2 className="h-4 w-4" /> Sentiment Analysis
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="py-0">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Average Sentiment:</span>
                          <Badge
                            variant="outline"
                            className={`${
                              selectedCall.metrics.averageSentiment > 0.2
                                ? "bg-green-500/10 text-green-500"
                                : selectedCall.metrics.averageSentiment < -0.2
                                  ? "bg-red-500/10 text-red-500"
                                  : "bg-gray-500/10 text-gray-500"
                            }`}
                          >
                            {selectedCall.metrics.averageSentiment.toFixed(2)}
                          </Badge>
                        </div>
                        <Progress
                          value={
                            (selectedCall.metrics.averageSentiment + 1) * 50
                          }
                          className="h-2"
                        />
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>Negative</span>
                          <span>Neutral</span>
                          <span>Positive</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-muted/30">
                    <CardHeader className="py-3">
                      <CardTitle className="text-sm flex items-center gap-1">
                        <Info className="h-4 w-4" /> Call Metrics
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="py-0">
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm flex items-center gap-1">
                            <CheckCircle className="h-3.5 w-3.5" /> Resolved:
                          </span>
                          <Badge
                            variant="outline"
                            className={
                              selectedCall.metrics.resolved
                                ? "bg-green-500/10 text-green-500"
                                : "bg-gray-500/10"
                            }
                          >
                            {selectedCall.metrics.resolved ? "Yes" : "No"}
                          </Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm flex items-center gap-1">
                            <PhoneForwarded className="h-3.5 w-3.5" />{" "}
                            Escalated:
                          </span>
                          <Badge
                            variant="outline"
                            className={
                              selectedCall.metrics.escalated
                                ? "bg-yellow-500/10 text-yellow-500"
                                : "bg-gray-500/10"
                            }
                          >
                            {selectedCall.metrics.escalated ? "Yes" : "No"}
                          </Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm flex items-center gap-1">
                            <MessageSquare className="h-3.5 w-3.5" /> Intent
                            Recognized:
                          </span>
                          <Badge
                            variant="outline"
                            className={
                              selectedCall.metrics.intentRecognized
                                ? "bg-blue-500/10 text-blue-500"
                                : "bg-gray-500/10"
                            }
                          >
                            {selectedCall.metrics.intentRecognized
                              ? "Yes"
                              : "No"}
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <ScrollArea className="h-[400px] rounded-md border p-4">
                  {selectedCall.transcript.map((entry, index) => (
                    <div
                      key={index}
                      className={`mb-4 ${entry.speaker === "agent" ? "pl-4" : "pr-4 text-right"}`}
                    >
                      <div className="font-semibold mb-1 flex items-center gap-2 text-sm">
                        <div
                          className={`w-6 h-6 rounded-full ${entry.speaker === "agent" ? "bg-primary/10" : "bg-secondary/10"} flex items-center justify-center`}
                        >
                          {entry.speaker === "agent" ? (
                            <Bot className="h-3 w-3 text-primary" />
                          ) : (
                            <User className="h-3 w-3 text-secondary-foreground" />
                          )}
                        </div>
                        {entry.speaker === "agent" ? "Agent" : "Caller"}
                        <span className="text-xs text-muted-foreground">
                          {new Date(entry.timestamp).toLocaleTimeString()}
                        </span>
                        {entry.intent && (
                          <Badge
                            variant="outline"
                            className="text-xs bg-blue-500/10 text-blue-500"
                          >
                            {entry.intent}
                          </Badge>
                        )}
                      </div>
                      <div
                        className={`p-3 rounded-lg ${entry.speaker === "agent" ? "bg-primary/10" : "bg-secondary/10"}`}
                      >
                        <p className="whitespace-pre-wrap">{entry.text}</p>
                        <div className="flex flex-wrap gap-2 mt-2">
                          {entry.sentiment !== undefined && (
                            <div className="text-xs flex items-center gap-1 bg-background/80 px-2 py-0.5 rounded-full">
                              <div
                                className="w-2 h-2 rounded-full"
                                style={{
                                  backgroundColor:
                                    entry.sentiment > 0.2
                                      ? "#22c55e"
                                      : entry.sentiment < -0.2
                                        ? "#ef4444"
                                        : "#9ca3af",
                                }}
                              />
                              <span>
                                Sentiment: {entry.sentiment.toFixed(2)}
                              </span>
                            </div>
                          )}
                          {entry.entities && entry.entities.length > 0 && (
                            <div className="text-xs flex items-center gap-1 bg-background/80 px-2 py-0.5 rounded-full">
                              <span>
                                Entities:{" "}
                                {entry.entities.map((e) => e.type).join(", ")}
                              </span>
                            </div>
                          )}
                          {entry.flagged && (
                            <div className="text-xs flex items-center gap-1 bg-red-500/10 text-red-500 px-2 py-0.5 rounded-full">
                              <AlertCircle className="h-3 w-3" />
                              <span>Flagged: {entry.flagReason}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </ScrollArea>
              </CardContent>
              <CardFooter className="flex justify-between border-t pt-4">
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Star className="mr-2 h-4 w-4" /> Rate Call
                  </Button>
                  <Button variant="outline" size="sm">
                    <FileText className="mr-2 h-4 w-4" /> Add Note
                  </Button>
                </div>
                {selectedCall.status === "active" && (
                  <Button
                    variant="destructive"
                    onClick={() => handleEndCall(selectedCall.id)}
                  >
                    <PhoneOff className="mr-2 h-4 w-4" /> End Call
                  </Button>
                )}
              </CardFooter>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="alerts">
          <div className="grid grid-cols-1 gap-6">
            {alerts.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Alert ID</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Severity</TableHead>
                    <TableHead>Call ID</TableHead>
                    <TableHead>Message</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {alerts.map((alert) => (
                    <TableRow key={alert.id}>
                      <TableCell className="font-medium">
                        {alert.id.substring(0, 8)}...
                      </TableCell>
                      <TableCell>{alert.type.replace("_", " ")}</TableCell>
                      <TableCell>{getSeverityBadge(alert.severity)}</TableCell>
                      <TableCell>{alert.callId.substring(0, 8)}...</TableCell>
                      <TableCell>{alert.message}</TableCell>
                      <TableCell>{alert.status}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          {alert.status === "new" && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleAcknowledgeAlert(alert.id)}
                            >
                              <AlertCircle className="mr-2 h-4 w-4" />{" "}
                              Acknowledge
                            </Button>
                          )}
                          {(alert.status === "new" ||
                            alert.status === "acknowledged") && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleResolveAlert(alert.id)}
                            >
                              <CheckCircle className="mr-2 h-4 w-4" /> Resolve
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground">No active alerts.</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="batches">
          <div className="text-center py-12">
            <p className="text-muted-foreground">
              Batch calling functionality is not yet implemented.
            </p>
          </div>
        </TabsContent>
      </Tabs>

      {/* New Agent Dialog */}
      <Dialog open={showNewAgentDialog} onOpenChange={setShowNewAgentDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Create New Agent</DialogTitle>
            <DialogDescription>
              Configure your new AI phone agent with personality and
              capabilities.
            </DialogDescription>
          </DialogHeader>
          <Tabs defaultValue="basic" className="mt-4">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="basic">Basic Info</TabsTrigger>
              <TabsTrigger value="voice">Voice & Personality</TabsTrigger>
              <TabsTrigger value="capabilities">Capabilities</TabsTrigger>
              <TabsTrigger value="compliance">Compliance</TabsTrigger>
            </TabsList>
            <TabsContent value="basic" className="space-y-4 mt-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  Agent Name
                </Label>
                <Input
                  id="name"
                  value={newAgentName}
                  onChange={(e) => setNewAgentName(e.target.value)}
                  className="col-span-3"
                  placeholder="e.g. Sarah from Customer Service"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="description" className="text-right">
                  Description
                </Label>
                <Textarea
                  id="description"
                  placeholder="Brief description of this agent's purpose"
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="industry" className="text-right">
                  Industry
                </Label>
                <Select defaultValue="customer-service">
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select industry" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="customer-service">
                      Customer Service
                    </SelectItem>
                    <SelectItem value="healthcare">Healthcare</SelectItem>
                    <SelectItem value="finance">Finance</SelectItem>
                    <SelectItem value="retail">Retail</SelectItem>
                    <SelectItem value="technology">Technology</SelectItem>
                    <SelectItem value="education">Education</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </TabsContent>
            <TabsContent value="voice" className="space-y-4 mt-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="voice" className="text-right">
                  Voice Gender
                </Label>
                <Select value={newAgentVoice} onValueChange={setNewAgentVoice}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select voice gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="neutral">Neutral</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="voice-provider" className="text-right">
                  Voice Provider
                </Label>
                <Select defaultValue="elevenlabs">
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select voice provider" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="elevenlabs">ElevenLabs</SelectItem>
                    <SelectItem value="amazon">Amazon Polly</SelectItem>
                    <SelectItem value="google">Google Cloud TTS</SelectItem>
                    <SelectItem value="azure">
                      Azure Cognitive Services
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="pitch" className="text-right">
                  Voice Pitch
                </Label>
                <div className="col-span-3">
                  <Slider defaultValue={[50]} max={100} step={1} />
                </div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="rate" className="text-right">
                  Speaking Rate
                </Label>
                <div className="col-span-3">
                  <Slider defaultValue={[50]} max={100} step={1} />
                </div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="tone" className="text-right">
                  Personality Tone
                </Label>
                <Select value={newAgentTone} onValueChange={setNewAgentTone}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select personality tone" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="professional">Professional</SelectItem>
                    <SelectItem value="friendly">Friendly</SelectItem>
                    <SelectItem value="casual">Casual</SelectItem>
                    <SelectItem value="formal">Formal</SelectItem>
                    <SelectItem value="empathetic">Empathetic</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="personality" className="text-right">
                  Personality Description
                </Label>
                <Textarea
                  id="personality"
                  placeholder="Describe how your agent should behave and speak..."
                  className="col-span-3 min-h-[100px]"
                  defaultValue="Friendly, professional, and helpful. Speaks clearly and concisely."
                />
              </div>
            </TabsContent>
            <TabsContent value="capabilities" className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm">Communication</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label
                        htmlFor="transfer-human"
                        className="cursor-pointer"
                      >
                        Transfer to Human
                      </Label>
                      <Switch id="transfer-human" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="send-sms" className="cursor-pointer">
                        Send SMS
                      </Label>
                      <Switch id="send-sms" />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="send-email" className="cursor-pointer">
                        Send Email
                      </Label>
                      <Switch id="send-email" />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label
                        htmlFor="schedule-callback"
                        className="cursor-pointer"
                      >
                        Schedule Callback
                      </Label>
                      <Switch id="schedule-callback" defaultChecked />
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm">
                      Language & Processing
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="multilingual" className="cursor-pointer">
                        Multilingual Support
                      </Label>
                      <Switch id="multilingual" />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label
                        htmlFor="sentiment-analysis"
                        className="cursor-pointer"
                      >
                        Sentiment Analysis
                      </Label>
                      <Switch id="sentiment-analysis" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label
                        htmlFor="entity-recognition"
                        className="cursor-pointer"
                      >
                        Entity Recognition
                      </Label>
                      <Switch id="entity-recognition" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label
                        htmlFor="intent-detection"
                        className="cursor-pointer"
                      >
                        Intent Detection
                      </Label>
                      <Switch id="intent-detection" defaultChecked />
                    </div>
                  </CardContent>
                </Card>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="languages" className="text-right">
                  Supported Languages
                </Label>
                <Select defaultValue="en">
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select languages" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="en-es">English & Spanish</SelectItem>
                    <SelectItem value="en-fr">English & French</SelectItem>
                    <SelectItem value="en-de">English & German</SelectItem>
                    <SelectItem value="all">All Available Languages</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="llm-provider" className="text-right">
                  AI Model
                </Label>
                <Select defaultValue="gpt-4">
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select AI model" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="gpt-4">GPT-4</SelectItem>
                    <SelectItem value="gpt-3.5">GPT-3.5 Turbo</SelectItem>
                    <SelectItem value="claude">Claude</SelectItem>
                    <SelectItem value="palm">PaLM</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </TabsContent>
            <TabsContent value="compliance" className="space-y-4 mt-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="recording-disclosure" className="text-right">
                  Recording Disclosure
                </Label>
                <div className="col-span-3 flex items-center gap-2">
                  <Switch id="recording-disclosure" defaultChecked />
                  <span className="text-sm text-muted-foreground">
                    Inform callers that calls may be recorded
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-4 items-start gap-4">
                <Label
                  htmlFor="required-disclosures"
                  className="text-right pt-2"
                >
                  Required Disclosures
                </Label>
                <Textarea
                  id="required-disclosures"
                  placeholder="Enter any required legal disclosures"
                  className="col-span-3"
                  defaultValue="This call may be recorded for quality and training purposes."
                />
              </div>
              <div className="grid grid-cols-4 items-start gap-4">
                <Label htmlFor="prohibited-phrases" className="text-right pt-2">
                  Prohibited Phrases
                </Label>
                <Textarea
                  id="prohibited-phrases"
                  placeholder="Enter phrases the agent should never say"
                  className="col-span-3"
                  defaultValue="guarantee, promise, 100%"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="sensitivity" className="text-right">
                  Content Filtering
                </Label>
                <div className="col-span-3">
                  <Select defaultValue="medium">
                    <SelectTrigger>
                      <SelectValue placeholder="Select filtering level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low (Basic Filtering)</SelectItem>
                      <SelectItem value="medium">
                        Medium (Standard Filtering)
                      </SelectItem>
                      <SelectItem value="high">
                        High (Strict Filtering)
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </TabsContent>
          </Tabs>
          <DialogFooter className="mt-6">
            <Button
              variant="outline"
              onClick={() => setShowNewAgentDialog(false)}
            >
              Cancel
            </Button>
            <Button onClick={handleCreateAgent}>
              <Plus className="mr-2 h-4 w-4" /> Create Agent
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Start Call Dialog */}
      <Dialog open={showCallDialog} onOpenChange={setShowCallDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Start New Call</DialogTitle>
            <DialogDescription>
              Start a call with {selectedAgent?.name}.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="callerId" className="text-right">
                Caller ID
              </Label>
              <Input
                id="callerId"
                placeholder="Enter caller ID or phone number"
                value={newCallerId}
                onChange={(e) => setNewCallerId(e.target.value)}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="callType" className="text-right">
                Call Type
              </Label>
              <Select defaultValue="inbound">
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select call type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="inbound">Inbound</SelectItem>
                  <SelectItem value="outbound">Outbound</SelectItem>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="callPurpose" className="text-right">
                Call Purpose
              </Label>
              <Select defaultValue="general">
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select purpose" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="general">General Inquiry</SelectItem>
                  <SelectItem value="support">Customer Support</SelectItem>
                  <SelectItem value="sales">Sales</SelectItem>
                  <SelectItem value="appointment">
                    Appointment Booking
                  </SelectItem>
                  <SelectItem value="followup">Follow-up</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-start gap-4">
              <Label htmlFor="callNotes" className="text-right pt-2">
                Notes
              </Label>
              <Textarea
                id="callNotes"
                placeholder="Add any context or notes for this call"
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCallDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleStartCall}>
              <PhoneCall className="mr-2 h-4 w-4" /> Start Call
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Template Dialog */}
      <Dialog open={showTemplateDialog} onOpenChange={setShowTemplateDialog}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Agent Templates</DialogTitle>
            <DialogDescription>
              Choose from pre-configured templates to quickly create specialized
              agents.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 py-4">
            <Card
              className="cursor-pointer hover:border-primary/50 transition-colors"
              onClick={() => setSelectedTemplate("customer-service")}
            >
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Customer Service</CardTitle>
                <CardDescription>General purpose support agent</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-sm text-muted-foreground">
                  <p>
                    Professional tone with support capabilities for handling
                    general inquiries and issue resolution.
                  </p>
                </div>
              </CardContent>
              <CardFooter className="pt-2">
                <Badge variant="outline">Most Popular</Badge>
              </CardFooter>
            </Card>
            <Card
              className="cursor-pointer hover:border-primary/50 transition-colors"
              onClick={() => setSelectedTemplate("appointment-scheduler")}
            >
              <CardHeader className="pb-2">
                <CardTitle className="text-base">
                  Appointment Scheduler
                </CardTitle>
                <CardDescription>Booking specialist</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-sm text-muted-foreground">
                  <p>
                    Friendly agent specialized in scheduling appointments and
                    managing calendar bookings.
                  </p>
                </div>
              </CardContent>
              <CardFooter className="pt-2">
                <Badge variant="outline">Calendar Integration</Badge>
              </CardFooter>
            </Card>
            <Card
              className="cursor-pointer hover:border-primary/50 transition-colors"
              onClick={() => setSelectedTemplate("sales-agent")}
            >
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Sales Agent</CardTitle>
                <CardDescription>Conversion focused</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-sm text-muted-foreground">
                  <p>
                    Persuasive agent designed to guide prospects through sales
                    processes and handle objections.
                  </p>
                </div>
              </CardContent>
              <CardFooter className="pt-2">
                <Badge variant="outline">CRM Integration</Badge>
              </CardFooter>
            </Card>
            <Card
              className="cursor-pointer hover:border-primary/50 transition-colors"
              onClick={() => setSelectedTemplate("healthcare")}
            >
              <CardHeader className="pb-2">
                <CardTitle className="text-base">
                  Healthcare Assistant
                </CardTitle>
                <CardDescription>Patient support</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-sm text-muted-foreground">
                  <p>
                    Empathetic agent with HIPAA compliance features for
                    healthcare appointment scheduling and inquiries.
                  </p>
                </div>
              </CardContent>
              <CardFooter className="pt-2">
                <Badge variant="outline">HIPAA Compliant</Badge>
              </CardFooter>
            </Card>
            <Card
              className="cursor-pointer hover:border-primary/50 transition-colors"
              onClick={() => setSelectedTemplate("technical-support")}
            >
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Technical Support</CardTitle>
                <CardDescription>IT troubleshooting</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-sm text-muted-foreground">
                  <p>
                    Knowledgeable agent specialized in technical troubleshooting
                    and step-by-step guidance.
                  </p>
                </div>
              </CardContent>
              <CardFooter className="pt-2">
                <Badge variant="outline">Knowledge Base</Badge>
              </CardFooter>
            </Card>
            <Card
              className="cursor-pointer hover:border-primary/50 transition-colors"
              onClick={() => setSelectedTemplate("multilingual")}
            >
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Multilingual Agent</CardTitle>
                <CardDescription>Language support</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-sm text-muted-foreground">
                  <p>
                    Agent with real-time translation capabilities supporting
                    multiple languages for global support.
                  </p>
                </div>
              </CardContent>
              <CardFooter className="pt-2">
                <Badge variant="outline">10+ Languages</Badge>
              </CardFooter>
            </Card>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowTemplateDialog(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                setShowTemplateDialog(false);
                setShowNewAgentDialog(true);
                // In a real implementation, we would pre-fill the agent form based on the selected template
                if (selectedTemplate === "customer-service") {
                  setNewAgentName("Customer Service Agent");
                  setNewAgentVoice("female");
                  setNewAgentTone("professional");
                }
              }}
              disabled={!selectedTemplate}
            >
              Use Template
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Help Dialog */}
      <Dialog open={showHelpDialog} onOpenChange={setShowHelpDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>AI Phone Agent Help</DialogTitle>
            <DialogDescription>
              Learn how to get the most out of your AI phone agents.
            </DialogDescription>
          </DialogHeader>
          <Tabs defaultValue="overview">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="setup">Setup Guide</TabsTrigger>
              <TabsTrigger value="best-practices">Best Practices</TabsTrigger>
              <TabsTrigger value="faq">FAQ</TabsTrigger>
            </TabsList>
            <TabsContent value="overview" className="space-y-4 mt-4">
              <div className="prose max-w-none">
                <h3>Welcome to AI Phone Agent</h3>
                <p>
                  AI Phone Agent allows you to create intelligent virtual agents
                  that can handle phone calls for your business. These agents
                  can understand natural language, respond appropriately, and
                  perform actions like scheduling appointments or answering
                  common questions.
                </p>
                <h4>Key Features</h4>
                <ul>
                  <li>
                    <strong>Natural Conversations:</strong> Agents can
                    understand context and maintain natural conversations
                  </li>
                  <li>
                    <strong>Voice Customization:</strong> Choose from various
                    voices and personalities
                  </li>
                  <li>
                    <strong>Integration:</strong> Connect with your calendar,
                    CRM, and other business systems
                  </li>
                  <li>
                    <strong>Analytics:</strong> Track call metrics and sentiment
                    analysis
                  </li>
                  <li>
                    <strong>Compliance:</strong> Built-in compliance features
                    for various industries
                  </li>
                </ul>
              </div>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
};

import React from "react";
import { Button } from "@/components/ui/button";
import { Link, useNavigate, useLocation } from "react-router-dom";
import {
  BarChart,
  Users,
  Calendar,
  MessageSquare,
  Settings,
  LogOut,
  Phone,
  Bot,
  Star,
  FileText,
  HelpCircle,
  Code,
  Boxes,
  Gauge,
  BrainCircuit,
  Building2,
  Wallet,
  Bell,
  Database,
  Terminal,
  Webhook,
  Layers,
  CreditCard,
  LineChart,
  PieChart,
  BarChart2,
} from "lucide-react";

import { Breadcrumb } from "@/components/ui/breadcrumb";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { Suspense } from "react";

const navigationItems = [
  {
    title: "Overview",
    items: [
      {
        name: "Dashboard",
        icon: <Gauge className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/dashboard",
      },
      {
        name: "Analytics",
        icon: <BarChart className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/dashboard/analytics",
      },
      {
        name: "Customers",
        icon: <Users className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/dashboard/customers",
      },
      {
        name: "Messages",
        icon: <MessageSquare className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/dashboard/messages",
      },
    ],
  },
  {
    title: "AI Features",
    items: [
      {
        name: "Phone Agent",
        icon: <Phone className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/phone-agent",
      },
      {
        name: "AI Assistant",
        icon: <Bot className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/dashboard/ai-assistant",
      },
      {
        name: "Smart Analytics",
        icon: <BrainCircuit className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/dashboard/smart-analytics",
      },
      {
        name: "Reputation",
        icon: <Star className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/dashboard/reputation",
      },
    ],
  },
  {
    title: "Business",
    items: [
      {
        name: "Appointments",
        icon: <Calendar className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/dashboard/appointments",
      },
      {
        name: "Billing",
        icon: <Wallet className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/dashboard/billing",
      },
      {
        name: "Notifications",
        icon: <Bell className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/dashboard/notifications",
      },
      {
        name: "Organization",
        icon: <Building2 className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/dashboard/organization",
      },
      {
        name: "Integrations",
        icon: <Boxes className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/dashboard/integrations",
      },
    ],
  },
  {
    title: "Developer",
    items: [
      {
        name: "API Explorer",
        icon: <Code className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/api-explorer",
      },
      {
        name: "Database Explorer",
        icon: <Database className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/database-explorer",
      },
      {
        name: "Webhooks",
        icon: <Webhook className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/webhooks",
      },
      {
        name: "Terminal",
        icon: <Terminal className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/terminal",
      },
      {
        name: "Documentation",
        icon: <FileText className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/docs",
      },
      {
        name: "Support",
        icon: <HelpCircle className="mr-2 h-5 w-5" />,
        path: "/CAPTIVITE-X/help",
      },
    ],
  },
];

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const navigate = useNavigate();
  const location = useLocation();

  // Enhanced active route detection with base URL support
  const isActiveRoute = (path: string) => {
    // Exact match
    if (location.pathname === path) return true;

    // Special case for dashboard root
    if (
      path === "/CAPTIVITE-X/dashboard" &&
      location.pathname === "/CAPTIVITE-X/dashboard"
    )
      return true;

    // Path prefix matching (but avoid matching dashboard root with all dashboard paths)
    if (path !== "/CAPTIVITE-X/dashboard" && location.pathname.startsWith(path))
      return true;

    return false;
  };

  // Check if current route is a dashboard route for layout persistence
  const isDashboardRoute =
    location.pathname === "/CAPTIVITE-X/dashboard" ||
    location.pathname.startsWith("/CAPTIVITE-X/dashboard/") ||
    location.pathname === "/CAPTIVITE-X/phone-agent" ||
    location.pathname === "/CAPTIVITE-X/api-explorer" ||
    location.pathname === "/CAPTIVITE-X/database-explorer" ||
    location.pathname === "/CAPTIVITE-X/webhooks" ||
    location.pathname === "/CAPTIVITE-X/terminal" ||
    location.pathname === "/CAPTIVITE-X/docs" ||
    location.pathname === "/CAPTIVITE-X/help";

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 h-screen w-64 bg-card border-r p-4 overflow-y-auto">
        <div className="flex flex-col h-full">
          <div className="mb-8">
            <Link to="/CAPTIVITE-X/dashboard" className="block">
              <h2 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary via-purple-500 to-secondary">
                Captivite
              </h2>
            </Link>
          </div>

          <nav className="space-y-8 flex-1 overflow-y-auto pr-2">
            {navigationItems.map((section) => (
              <div key={section.title}>
                <h3 className="text-xs uppercase font-semibold text-muted-foreground mb-3 px-2">
                  {section.title}
                </h3>
                <div className="space-y-1">
                  {section.items.map((item) => (
                    <Button
                      key={item.path}
                      variant={isActiveRoute(item.path) ? "secondary" : "ghost"}
                      className="w-full justify-start"
                      asChild
                    >
                      <Link to={item.path}>
                        {item.icon}
                        {item.name}
                      </Link>
                    </Button>
                  ))}
                </div>
              </div>
            ))}
          </nav>

          <div className="pt-6 mt-auto border-t space-y-3">
            <Button
              variant={
                isActiveRoute("/CAPTIVITE-X/dashboard/settings")
                  ? "secondary"
                  : "ghost"
              }
              className="w-full justify-start"
              asChild
            >
              <Link to="/CAPTIVITE-X/dashboard/settings">
                <Settings className="mr-2 h-5 w-5" />
                Settings
              </Link>
            </Button>

            <Button
              variant="ghost"
              className="w-full justify-start text-muted-foreground"
              onClick={() => navigate("/CAPTIVITE-X/login")}
            >
              <LogOut className="mr-2 h-5 w-5" />
              Logout
            </Button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <main className="ml-64 min-h-screen">
        <div className="p-8">
          <Breadcrumb />
          <Suspense fallback={<LoadingSpinner />}>{children}</Suspense>
        </div>
      </main>
    </div>
  );
}

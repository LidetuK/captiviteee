import React from "react";
import AIAssistantPanel from "../AIAssistantPanel";

const AIAssistantPanelWrapper = () => {
  return <AIAssistantPanel />;
};

export default AIAssistantPanelWrapper;

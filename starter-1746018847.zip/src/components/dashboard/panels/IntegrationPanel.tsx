import React from "react";
import IntegrationHub from "../IntegrationHub";

const IntegrationPanel = () => {
  return <IntegrationHub />;
};

export default IntegrationPanel;

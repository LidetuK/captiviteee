import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { format } from "date-fns";
import {
  CalendarIcon,
  Image,
  Link,
  Smile,
  Clock,
  Sparkles,
  Wand2,
} from "lucide-react";

interface PostComposerProps {
  onClose: () => void;
}

const PostComposer: React.FC<PostComposerProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState("compose");
  const [postContent, setPostContent] = useState("");
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(
    new Date(),
  );
  const [selectedTime, setSelectedTime] = useState("12:00");
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([
    "facebook",
    "twitter",
  ]);
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const togglePlatform = (platform: string) => {
    if (selectedPlatforms.includes(platform)) {
      setSelectedPlatforms(selectedPlatforms.filter((p) => p !== platform));
    } else {
      setSelectedPlatforms([...selectedPlatforms, platform]);
    }
  };

  const generateAISuggestions = () => {
    setIsGenerating(true);
    // Simulate AI generation
    setTimeout(() => {
      setAiSuggestions([
        "Excited to announce our new feature that will revolutionize how you manage social media! #SocialMediaManagement #Productivity",
        "Looking for a better way to manage your social media? Our new feature has got you covered! Check it out now. #Innovation",
        "We've been working hard behind the scenes, and today we're thrilled to share our latest innovation with you! #NewFeature #SocialMedia",
      ]);
      setIsGenerating(false);
    }, 1500);
  };

  const applyAISuggestion = (suggestion: string) => {
    setPostContent(suggestion);
    setActiveTab("compose");
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create New Post</DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="compose">Compose</TabsTrigger>
            <TabsTrigger value="schedule">Schedule</TabsTrigger>
            <TabsTrigger value="ai-assist">
              <Sparkles className="mr-2 h-4 w-4" />
              AI Assist
            </TabsTrigger>
          </TabsList>

          <TabsContent value="compose" className="space-y-4 py-4">
            <div className="space-y-4">
              <div>
                <Label htmlFor="platforms">Select Platforms</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  <Button
                    type="button"
                    variant={
                      selectedPlatforms.includes("facebook")
                        ? "default"
                        : "outline"
                    }
                    size="sm"
                    onClick={() => togglePlatform("facebook")}
                    className="flex items-center"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-2 h-4 w-4"
                    >
                      <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                    </svg>
                    Facebook
                  </Button>
                  <Button
                    type="button"
                    variant={
                      selectedPlatforms.includes("twitter")
                        ? "default"
                        : "outline"
                    }
                    size="sm"
                    onClick={() => togglePlatform("twitter")}
                    className="flex items-center"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-2 h-4 w-4"
                    >
                      <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
                    </svg>
                    Twitter
                  </Button>
                  <Button
                    type="button"
                    variant={
                      selectedPlatforms.includes("instagram")
                        ? "default"
                        : "outline"
                    }
                    size="sm"
                    onClick={() => togglePlatform("instagram")}
                    className="flex items-center"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-2 h-4 w-4"
                    >
                      <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
                      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
                    </svg>
                    Instagram
                  </Button>
                  <Button
                    type="button"
                    variant={
                      selectedPlatforms.includes("linkedin")
                        ? "default"
                        : "outline"
                    }
                    size="sm"
                    onClick={() => togglePlatform("linkedin")}
                    className="flex items-center"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-2 h-4 w-4"
                    >
                      <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
                      <rect width="4" height="12" x="2" y="9" />
                      <circle cx="4" cy="4" r="2" />
                    </svg>
                    LinkedIn
                  </Button>
                  <Button
                    type="button"
                    variant={
                      selectedPlatforms.includes("tiktok")
                        ? "default"
                        : "outline"
                    }
                    size="sm"
                    onClick={() => togglePlatform("tiktok")}
                    className="flex items-center"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-2 h-4 w-4"
                    >
                      <path d="M9 12a4 4 0 1 0 0 8 4 4 0 0 0 0-8z" />
                      <path d="M15 8a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" />
                      <path d="M15 8v8a4 4 0 0 1-4 4" />
                      <line x1="15" x2="15" y1="4" y2="12" />
                    </svg>
                    TikTok
                  </Button>
                </div>
              </div>

              <div>
                <Label htmlFor="post-content">Post Content</Label>
                <Textarea
                  id="post-content"
                  placeholder="What's on your mind?"
                  className="min-h-[150px] mt-2"
                  value={postContent}
                  onChange={(e) => setPostContent(e.target.value)}
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>{postContent.length} characters</span>
                  <span>
                    {selectedPlatforms.includes("twitter") && (
                      <span
                        className={
                          postContent.length > 280 ? "text-red-500" : ""
                        }
                      >
                        {280 - postContent.length} characters left for Twitter
                      </span>
                    )}
                  </span>
                </div>
              </div>

              <div className="flex space-x-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="flex items-center"
                >
                  <Image className="mr-2 h-4 w-4" /> Add Media
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="flex items-center"
                >
                  <Link className="mr-2 h-4 w-4" /> Add Link
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="flex items-center"
                >
                  <Smile className="mr-2 h-4 w-4" /> Add Emoji
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="flex items-center"
                  onClick={() => setActiveTab("ai-assist")}
                >
                  <Wand2 className="mr-2 h-4 w-4" /> AI Assist
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="schedule" className="space-y-4 py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Publication Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {selectedDate
                        ? format(selectedDate, "PPP")
                        : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={setSelectedDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label>Publication Time</Label>
                <div className="flex space-x-2">
                  <Select value={selectedTime} onValueChange={setSelectedTime}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select time" />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({ length: 24 }).map((_, hour) =>
                        [0, 30].map((minute) => {
                          const timeString = `${hour.toString().padStart(2, "0")}:${minute.toString().padStart(2, "0")}`;
                          return (
                            <SelectItem key={timeString} value={timeString}>
                              {timeString}
                            </SelectItem>
                          );
                        }),
                      )}
                    </SelectContent>
                  </Select>
                  <Button variant="outline" className="flex items-center">
                    <Clock className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="optimal-time">
                  Use AI to find optimal posting time
                </Label>
                <Switch id="optimal-time" />
              </div>
              <p className="text-sm text-muted-foreground">
                Our AI will analyze your audience's activity patterns and
                schedule your post for maximum engagement.
              </p>
            </div>

            <div className="space-y-2">
              <Label>Posting Frequency</Label>
              <Select defaultValue="once">
                <SelectTrigger>
                  <SelectValue placeholder="Select frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="once">Post once</SelectItem>
                  <SelectItem value="daily">Post daily</SelectItem>
                  <SelectItem value="weekly">Post weekly</SelectItem>
                  <SelectItem value="monthly">Post monthly</SelectItem>
                  <SelectItem value="custom">Custom schedule</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </TabsContent>

          <TabsContent value="ai-assist" className="space-y-4 py-4">
            <div className="space-y-4">
              <div className="bg-muted p-4 rounded-lg">
                <h3 className="font-medium flex items-center">
                  <Sparkles className="mr-2 h-4 w-4 text-primary" /> AI Content
                  Generator
                </h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Let our AI help you create engaging content for your social
                  media posts.
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="ai-prompt">
                  What would you like to post about?
                </Label>
                <Textarea
                  id="ai-prompt"
                  placeholder="E.g., Announce our new feature that helps businesses manage social media more efficiently"
                  className="min-h-[100px]"
                />
              </div>

              <div className="space-y-2">
                <Label>Tone</Label>
                <Select defaultValue="professional">
                  <SelectTrigger>
                    <SelectValue placeholder="Select tone" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="professional">Professional</SelectItem>
                    <SelectItem value="casual">Casual</SelectItem>
                    <SelectItem value="enthusiastic">Enthusiastic</SelectItem>
                    <SelectItem value="informative">Informative</SelectItem>
                    <SelectItem value="humorous">Humorous</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex space-x-2">
                <Button
                  type="button"
                  onClick={generateAISuggestions}
                  disabled={isGenerating}
                  className="flex items-center"
                >
                  {isGenerating ? (
                    <>
                      <svg
                        className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        ></circle>
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        ></path>
                      </svg>
                      Generating...
                    </>
                  ) : (
                    <>
                      <Wand2 className="mr-2 h-4 w-4" /> Generate Suggestions
                    </>
                  )}
                </Button>
              </div>

              {aiSuggestions.length > 0 && (
                <div className="space-y-3 mt-4">
                  <Label>AI Suggestions</Label>
                  {aiSuggestions.map((suggestion, index) => (
                    <div
                      key={index}
                      className="p-3 border rounded-md hover:border-primary cursor-pointer"
                      onClick={() => applyAISuggestion(suggestion)}
                    >
                      <p className="text-sm">{suggestion}</p>
                      <div className="flex justify-end mt-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            applyAISuggestion(suggestion);
                          }}
                        >
                          Use This
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <div className="flex justify-between w-full">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <div className="space-x-2">
              <Button variant="outline">Save as Draft</Button>
              <Button>Schedule Post</Button>
            </div>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default PostComposer;

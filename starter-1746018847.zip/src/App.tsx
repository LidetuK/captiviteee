import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import Home from "./components/home";
import TempoRoutes from "./components/TempoRoutes";
import LoginPage from "./components/auth/LoginPage";
import { LoadingStoreProvider } from "./lib/store";
import { PrivateRoute } from "./lib/store/auth";
import { AuthProvider } from "./lib/auth.tsx";
import CustomerDashboard from "./components/dashboard/CustomerDashboard";
import DashboardPage from "./pages/DashboardPage";
import ReputationPage from "./pages/ReputationPage";
import BackendConsolePage from "./pages/BackendConsolePage";
import Dashboard from "./components/dashboard/Dashboard";
import Analytics from "./components/analytics/Analytics";
import Customers from "./components/customers/Customers";
import Messages from "./components/messages/Messages";
import SocialMedia from "./components/social/SocialMedia";
import Settings from "./components/settings/Settings";
import NotFound from "./components/common/NotFound";
import Layout from "./components/layout/Layout";

// Import new components for navigation
import PhoneAgentDashboard from "./components/phone-agent/PhoneAgentDashboard";
import AIAssistantPanel from "./components/dashboard/panels/AIAssistantPanel";
import SmartAnalyticsPanel from "./components/dashboard/panels/SmartAnalyticsPanel";
import ReputationManagement from "./components/reputation/ReputationManagement";
import IntegrationHub from "./components/dashboard/IntegrationHub";

// Placeholder components for routes that don't have components yet
const Appointments = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold mb-4">Appointments</h1>
    <p>Appointments management coming soon</p>
  </div>
);
const Billing = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold mb-4">Billing</h1>
    <p>Billing management coming soon</p>
  </div>
);
const Notifications = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold mb-4">Notifications</h1>
    <p>Notifications center coming soon</p>
  </div>
);
const Organization = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold mb-4">Organization</h1>
    <p>Organization management coming soon</p>
  </div>
);

// New placeholder components for additional AI features
const ContentGenerator = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold mb-4">Content Generator</h1>
    <p>AI-powered content generation coming soon</p>
  </div>
);
const CustomerSupport = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold mb-4">Customer Support</h1>
    <p>AI customer support automation coming soon</p>
  </div>
);
const DocumentAnalysis = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold mb-4">Document Analysis</h1>
    <p>AI document analysis and extraction coming soon</p>
  </div>
);
const EmailAutomation = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold mb-4">Email Automation</h1>
    <p>Smart email automation coming soon</p>
  </div>
);
const LeadGeneration = () => (
  <div className="p-6">
    <h1 className="text-2xl font-bold mb-4">Lead Generation</h1>
    <p>AI-powered lead generation coming soon</p>
  </div>
);

const App: React.FC = () => {
  return (
    <LoadingStoreProvider>
      <AuthProvider>
        <Router>
          {/* Tempo routes component that internally uses useRoutes */}
          {import.meta.env.VITE_TEMPO === "true" && <TempoRoutes />}

          <Routes>
            <Route path="/login" element={<LoginPage />} />

            {/* Main layout with sidebar */}
            <Route path="/" element={<Layout />}>
              <Route index element={<Navigate to="/dashboard" replace />} />
              <Route path="dashboard" element={<Dashboard />} />
              <Route path="analytics" element={<Analytics />} />
              <Route path="customers" element={<Customers />} />
              <Route path="messages" element={<Messages />} />
              <Route path="social-media" element={<SocialMedia />} />
              <Route path="phone-agent" element={<PhoneAgentDashboard />} />
              <Route path="ai-assistant" element={<AIAssistantPanel />} />
              <Route path="smart-analytics" element={<SmartAnalyticsPanel />} />
              <Route path="reputation" element={<ReputationManagement />} />
              <Route path="content-generator" element={<ContentGenerator />} />
              <Route path="customer-support" element={<CustomerSupport />} />
              <Route path="document-analysis" element={<DocumentAnalysis />} />
              <Route path="email-automation" element={<EmailAutomation />} />
              <Route path="lead-generation" element={<LeadGeneration />} />
              <Route path="appointments" element={<Appointments />} />
              <Route path="billing" element={<Billing />} />
              <Route path="notifications" element={<Notifications />} />
              <Route path="organization" element={<Organization />} />
              <Route path="integrations" element={<IntegrationHub />} />
              <Route path="settings" element={<Settings />} />
              <Route path="*" element={<NotFound />} />
            </Route>

            {/* Protected routes */}
            <Route element={<PrivateRoute />}>
              <Route path="/dashboard/*" element={<CustomerDashboard />} />
              <Route path="/reputation" element={<ReputationPage />} />
              <Route path="/backend-console" element={<BackendConsolePage />} />
            </Route>

            {/* Add tempobook route before the catch-all */}
            {import.meta.env.VITE_TEMPO === "true" && (
              <Route path="/tempobook/*" element={<></>} />
            )}
          </Routes>
        </Router>
      </AuthProvider>
    </LoadingStoreProvider>
  );
};

export default App;

import {
  Review,
  ReviewSource,
  ReputationMetrics,
  Competitor,
  ResponseTemplate,
  ReputationManager,
} from "./reputationManager";

// Create a more robust mock implementation of the ReputationManager
export class MockReputationManager implements ReputationManager {
  private reviews: Review[] = [];
  private sources: ReviewSource[] = [];
  private competitors: Competitor[] = [];
  private templates: ResponseTemplate[] = [];
  private metrics: ReputationMetrics | null = null;

  constructor() {
    this.initializeMockData();
  }

  private initializeMockData() {
    // Add sources
    this.addSource({
      id: "source_google",
      name: "Google Business",
      type: "google",
      url: "https://business.google.com/dashboard",
      enabled: true,
      syncFrequency: "daily",
      lastSyncTime: new Date(Date.now() - 12 * 60 * 60 * 1000),
      reviewCount: 42,
      averageRating: 4.2,
    });

    this.addSource({
      id: "source_yelp",
      name: "Yelp",
      type: "yelp",
      url: "https://biz.yelp.com",
      enabled: true,
      syncFrequency: "daily",
      lastSyncTime: new Date(Date.now() - 8 * 60 * 60 * 1000),
      reviewCount: 28,
      averageRating: 3.8,
    });

    this.addSource({
      id: "source_facebook",
      name: "Facebook",
      type: "facebook",
      url: "https://facebook.com/business",
      enabled: true,
      syncFrequency: "weekly",
      lastSyncTime: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      reviewCount: 15,
      averageRating: 4.5,
    });

    // Add reviews
    const reviewsData = [
      {
        id: "review_1",
        sourceId: "source_google",
        sourceName: "Google Business",
        authorName: "John Smith",
        authorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=john",
        rating: 5,
        content:
          "Excellent service! The team was very professional and responsive to all my needs. Would definitely recommend to anyone looking for quality service.",
        publishedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        status: "new",
        sentiment: { score: 0.9, magnitude: 1.5 },
        keywords: [
          { keyword: "excellent", relevance: 0.9 },
          { keyword: "professional", relevance: 0.8 },
          { keyword: "responsive", relevance: 0.7 },
        ],
      },
      {
        id: "review_2",
        sourceId: "source_yelp",
        sourceName: "Yelp",
        authorName: "Sarah Johnson",
        authorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=sarah",
        rating: 4,
        content:
          "Great experience overall. The staff was friendly and helpful. Would recommend to others looking for quality service.",
        publishedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
        status: "new",
        sentiment: { score: 0.7, magnitude: 1.2 },
        keywords: [
          { keyword: "great", relevance: 0.8 },
          { keyword: "friendly", relevance: 0.7 },
          { keyword: "helpful", relevance: 0.6 },
        ],
      },
      {
        id: "review_3",
        sourceId: "source_google",
        sourceName: "Google Business",
        authorName: "Michael Brown",
        authorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=michael",
        rating: 2,
        content:
          "Service was slower than expected. Had to follow up multiple times to get a response. Not very impressed with the communication.",
        publishedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
        status: "flagged",
        sentiment: { score: -0.5, magnitude: 1.0 },
        keywords: [
          { keyword: "slow", relevance: 0.8 },
          { keyword: "follow up", relevance: 0.7 },
          { keyword: "communication", relevance: 0.6 },
        ],
      },
      {
        id: "review_4",
        sourceId: "source_yelp",
        sourceName: "Yelp",
        authorName: "Emily Davis",
        authorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=emily",
        rating: 3,
        content:
          "Average service. Some things could be improved, particularly the response time. But overall, not bad.",
        publishedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
        status: "responded",
        responseContent:
          "Thank you for your feedback, Emily. We're constantly working to improve our services and appreciate your input. We've taken note of your comments about response time and are implementing changes to address this.",
        responsePublishedAt: new Date(Date.now() - 9 * 24 * 60 * 60 * 1000),
        sentiment: { score: 0.1, magnitude: 0.8 },
        keywords: [
          { keyword: "average", relevance: 0.7 },
          { keyword: "improve", relevance: 0.6 },
          { keyword: "response time", relevance: 0.5 },
        ],
      },
      {
        id: "review_5",
        sourceId: "source_facebook",
        sourceName: "Facebook",
        authorName: "Robert Wilson",
        authorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=robert",
        rating: 5,
        content:
          "Absolutely fantastic! The team went above and beyond to meet my needs. I'm extremely satisfied with the results and will definitely be a returning customer.",
        publishedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
        status: "new",
        sentiment: { score: 0.95, magnitude: 1.8 },
        keywords: [
          { keyword: "fantastic", relevance: 0.9 },
          { keyword: "above and beyond", relevance: 0.8 },
          { keyword: "satisfied", relevance: 0.7 },
        ],
      },
      {
        id: "review_6",
        sourceId: "source_google",
        sourceName: "Google Business",
        authorName: "Jennifer Lee",
        authorAvatar:
          "https://api.dicebear.com/7.x/avataaars/svg?seed=jennifer",
        rating: 4,
        content:
          "Very good service. The staff was knowledgeable and helped me find exactly what I was looking for. Would use again.",
        publishedAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
        status: "responded",
        responseContent:
          "Thank you for your kind review, Jennifer! We're glad we could help you find what you needed. Looking forward to serving you again soon!",
        responsePublishedAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
        sentiment: { score: 0.8, magnitude: 1.3 },
        keywords: [
          { keyword: "good", relevance: 0.8 },
          { keyword: "knowledgeable", relevance: 0.7 },
          { keyword: "helpful", relevance: 0.6 },
        ],
      },
      {
        id: "review_7",
        sourceId: "source_yelp",
        sourceName: "Yelp",
        authorName: "David Martinez",
        authorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=david",
        rating: 1,
        content:
          "Terrible experience. Waited for hours and still didn't get what I needed. Customer service was unhelpful and rude. Would not recommend.",
        publishedAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000),
        status: "flagged",
        sentiment: { score: -0.9, magnitude: 1.7 },
        keywords: [
          { keyword: "terrible", relevance: 0.9 },
          { keyword: "waited", relevance: 0.8 },
          { keyword: "unhelpful", relevance: 0.7 },
          { keyword: "rude", relevance: 0.6 },
        ],
      },
      {
        id: "review_8",
        sourceId: "source_facebook",
        sourceName: "Facebook",
        authorName: "Lisa Thompson",
        authorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=lisa",
        rating: 5,
        content:
          "Outstanding service! The team was incredibly helpful and went out of their way to ensure I had everything I needed. Highly recommend!",
        publishedAt: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000),
        status: "new",
        sentiment: { score: 0.9, magnitude: 1.6 },
        keywords: [
          { keyword: "outstanding", relevance: 0.9 },
          { keyword: "helpful", relevance: 0.8 },
          { keyword: "recommend", relevance: 0.7 },
        ],
      },
      {
        id: "review_9",
        sourceId: "source_google",
        sourceName: "Google Business",
        authorName: "James Wilson",
        authorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=james",
        rating: 3,
        content:
          "Decent service but nothing special. Got what I needed but took longer than expected. Room for improvement.",
        publishedAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        status: "new",
        sentiment: { score: 0.2, magnitude: 0.7 },
        keywords: [
          { keyword: "decent", relevance: 0.7 },
          { keyword: "longer", relevance: 0.6 },
          { keyword: "improvement", relevance: 0.5 },
        ],
      },
      {
        id: "review_10",
        sourceId: "source_yelp",
        sourceName: "Yelp",
        authorName: "Patricia Garcia",
        authorAvatar:
          "https://api.dicebear.com/7.x/avataaars/svg?seed=patricia",
        rating: 4,
        content:
          "Good experience overall. Staff was friendly and the service was quick. Would use again in the future.",
        publishedAt: new Date(Date.now() - 35 * 24 * 60 * 60 * 1000),
        status: "responded",
        responseContent:
          "Thank you for your review, Patricia! We're happy to hear you had a good experience and look forward to serving you again soon.",
        responsePublishedAt: new Date(Date.now() - 34 * 24 * 60 * 60 * 1000),
        sentiment: { score: 0.7, magnitude: 1.2 },
        keywords: [
          { keyword: "good", relevance: 0.8 },
          { keyword: "friendly", relevance: 0.7 },
          { keyword: "quick", relevance: 0.6 },
        ],
      },
    ];

    reviewsData.forEach((review) => this.addReview(review));

    // Add competitors
    this.addCompetitor({
      id: "competitor_1",
      name: "Competitor A",
      website: "https://competitora.com",
      sources: [
        {
          sourceType: "google",
          url: "https://business.google.com/competitor-a",
        },
        { sourceType: "yelp", url: "https://yelp.com/biz/competitor-a" },
      ],
      averageRating: 3.8,
      totalReviews: 87,
      lastUpdated: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    });

    this.addCompetitor({
      id: "competitor_2",
      name: "Competitor B",
      website: "https://competitorb.com",
      sources: [
        {
          sourceType: "google",
          url: "https://business.google.com/competitor-b",
        },
        { sourceType: "yelp", url: "https://yelp.com/biz/competitor-b" },
        { sourceType: "facebook", url: "https://facebook.com/competitor-b" },
      ],
      averageRating: 4.1,
      totalReviews: 124,
      lastUpdated: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    });

    this.addCompetitor({
      id: "competitor_3",
      name: "Competitor C",
      website: "https://competitorc.com",
      sources: [
        {
          sourceType: "google",
          url: "https://business.google.com/competitor-c",
        },
      ],
      averageRating: 3.5,
      totalReviews: 56,
      lastUpdated: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    });

    // Add response templates
    this.addTemplate({
      id: "template_1",
      name: "Positive Review Response",
      category: "positive",
      content:
        "Thank you for your kind words, {{name}}! We're thrilled to hear about your positive experience and look forward to serving you again soon.",
      sentiment: "positive",
      createdBy: "admin",
      createdAt: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000),
      usageCount: 28,
    });

    this.addTemplate({
      id: "template_2",
      name: "Negative Review Response",
      category: "negative",
      content:
        "We're sorry to hear about your experience, {{name}}. We take your feedback seriously and would like to make things right. Please contact our customer service team at support@example.com so we can address your concerns directly.",
      sentiment: "negative",
      createdBy: "admin",
      createdAt: new Date(Date.now() - 55 * 24 * 60 * 60 * 1000),
      usageCount: 12,
    });

    this.addTemplate({
      id: "template_3",
      name: "Neutral Review Response",
      category: "neutral",
      content:
        "Thank you for your feedback, {{name}}. We appreciate you taking the time to share your experience with us. We're constantly working to improve our services and your input helps us do that.",
      sentiment: "neutral",
      createdBy: "admin",
      createdAt: new Date(Date.now() - 50 * 24 * 60 * 60 * 1000),
      usageCount: 18,
    });

    // Generate metrics
    this.generateMetrics();
  }

  private generateMetrics() {
    const now = new Date();
    const lastMonth = new Date();
    lastMonth.setMonth(lastMonth.getMonth() - 1);

    // Calculate metrics from reviews
    const totalReviews = this.reviews.length;
    let sumRatings = 0;
    const reviewsBySource: Record<string, number> = {};
    const reviewsByRating: Record<string, number> = {
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
    };

    let respondedCount = 0;
    let sumSentiment = 0;

    this.reviews.forEach((review) => {
      sumRatings += review.rating;

      // Count by source
      if (reviewsBySource[review.sourceName]) {
        reviewsBySource[review.sourceName]++;
      } else {
        reviewsBySource[review.sourceName] = 1;
      }

      // Count by rating
      reviewsByRating[review.rating.toString()]++;

      // Count responded
      if (review.status === "responded") {
        respondedCount++;
      }

      // Sum sentiment
      if (review.sentiment !== undefined) {
        sumSentiment += review.sentiment.score;
      }
    });

    const averageRating = totalReviews > 0 ? sumRatings / totalReviews : 0;
    const responseRate = totalReviews > 0 ? respondedCount / totalReviews : 0;
    const sentimentScore = totalReviews > 0 ? sumSentiment / totalReviews : 0;

    // Generate rating trend (last 6 months)
    const ratingTrend = [];
    const volumeTrend = [];

    for (let i = 5; i >= 0; i--) {
      const month = new Date();
      month.setMonth(month.getMonth() - i);
      const monthName = month.toLocaleString("default", { month: "short" });

      // Simulate some variation in ratings and volume over time
      const baseRating = 3.5 + Math.random() * 1.5 - 0.5;
      const baseVolume = 10 + Math.floor(Math.random() * 20);

      ratingTrend.push({
        date: monthName,
        rating: parseFloat(baseRating.toFixed(1)),
      });

      volumeTrend.push({
        date: monthName,
        count: baseVolume,
      });
    }

    // Create metrics object
    this.metrics = {
      id: "current",
      period: "monthly",
      startDate: lastMonth,
      endDate: now,
      metrics: {
        averageRating,
        totalReviews,
        reviewsBySource: reviewsBySource,
        reviewsByRating,
        responseRate,
        averageResponseTime: 24, // Mock value in hours
        sentimentScore,
        topKeywords: [
          { keyword: "excellent", count: 15, sentiment: 0.9 },
          { keyword: "professional", count: 12, sentiment: 0.8 },
          { keyword: "helpful", count: 10, sentiment: 0.7 },
          { keyword: "friendly", count: 8, sentiment: 0.8 },
          { keyword: "responsive", count: 7, sentiment: 0.6 },
        ],
        ratingTrend,
        volumeTrend,
      },
    };
  }

  // Reviews methods
  getAllReviews(): Review[] {
    return this.reviews;
  }

  getReviews(filters: any = {}): Review[] {
    let filteredReviews = [...this.reviews];

    // Apply filters
    if (filters.sourceId) {
      filteredReviews = filteredReviews.filter(
        (r) => r.sourceId === filters.sourceId,
      );
    }

    if (filters.status) {
      filteredReviews = filteredReviews.filter(
        (r) => r.status === filters.status,
      );
    }

    if (filters.minRating !== undefined) {
      filteredReviews = filteredReviews.filter(
        (r) => r.rating >= filters.minRating,
      );
    }

    if (filters.maxRating !== undefined) {
      filteredReviews = filteredReviews.filter(
        (r) => r.rating <= filters.maxRating,
      );
    }

    if (filters.dateFrom) {
      filteredReviews = filteredReviews.filter(
        (r) => new Date(r.publishedAt) >= new Date(filters.dateFrom),
      );
    }

    if (filters.dateTo) {
      filteredReviews = filteredReviews.filter(
        (r) => new Date(r.publishedAt) <= new Date(filters.dateTo),
      );
    }

    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      filteredReviews = filteredReviews.filter(
        (r) =>
          r.content.toLowerCase().includes(searchLower) ||
          r.authorName.toLowerCase().includes(searchLower),
      );
    }

    // Sort reviews
    if (filters.sortBy) {
      filteredReviews.sort((a, b) => {
        if (filters.sortBy === "date") {
          return (
            new Date(b.publishedAt).getTime() -
            new Date(a.publishedAt).getTime()
          );
        } else if (filters.sortBy === "rating") {
          return filters.sortOrder === "asc"
            ? a.rating - b.rating
            : b.rating - a.rating;
        }
        return 0;
      });
    } else {
      // Default sort by date (newest first)
      filteredReviews.sort(
        (a, b) =>
          new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime(),
      );
    }

    return filteredReviews;
  }

  getReview(id: string): Review | undefined {
    return this.reviews.find((r) => r.id === id);
  }

  addReview(review: any): void {
    this.reviews.push(review);
    this.generateMetrics(); // Update metrics when a review is added
  }

  updateReview(id: string, updates: Partial<Review>): void {
    const index = this.reviews.findIndex((r) => r.id === id);
    if (index !== -1) {
      this.reviews[index] = { ...this.reviews[index], ...updates };
      this.generateMetrics(); // Update metrics when a review is updated
    }
  }

  deleteReview(id: string): void {
    this.reviews = this.reviews.filter((r) => r.id !== id);
    this.generateMetrics(); // Update metrics when a review is deleted
  }

  createResponse(response: any): void {
    const { reviewId, content, status } = response;
    const review = this.getReview(reviewId);
    if (review) {
      this.updateReview(reviewId, {
        status: status || "responded",
        responseContent: content,
        responsePublishedAt: new Date(),
      });
    }
  }

  // Sources methods
  getAllSources(): ReviewSource[] {
    return this.sources;
  }

  getSource(id: string): ReviewSource | undefined {
    return this.sources.find((s) => s.id === id);
  }

  addSource(source: any): void {
    this.sources.push(source);
  }

  updateSource(id: string, updates: Partial<ReviewSource>): void {
    const index = this.sources.findIndex((s) => s.id === id);
    if (index !== -1) {
      this.sources[index] = { ...this.sources[index], ...updates };
    }
  }

  deleteSource(id: string): void {
    this.sources = this.sources.filter((s) => s.id !== id);
    // Also delete all reviews from this source
    this.reviews = this.reviews.filter((r) => r.sourceId !== id);
    this.generateMetrics(); // Update metrics when a source and its reviews are deleted
  }

  // Competitors methods
  getAllCompetitors(): Competitor[] {
    return this.competitors;
  }

  getCompetitor(id: string): Competitor | undefined {
    return this.competitors.find((c) => c.id === id);
  }

  addCompetitor(competitor: any): void {
    this.competitors.push(competitor);
  }

  updateCompetitor(id: string, updates: Partial<Competitor>): void {
    const index = this.competitors.findIndex((c) => c.id === id);
    if (index !== -1) {
      this.competitors[index] = { ...this.competitors[index], ...updates };
    }
  }

  deleteCompetitor(id: string): void {
    this.competitors = this.competitors.filter((c) => c.id !== id);
  }

  // Templates methods
  getAllTemplates(): ResponseTemplate[] {
    return this.templates;
  }

  getTemplate(id: string): ResponseTemplate | undefined {
    return this.templates.find((t) => t.id === id);
  }

  addTemplate(template: any): void {
    this.templates.push(template);
  }

  updateTemplate(id: string, updates: Partial<ResponseTemplate>): void {
    const index = this.templates.findIndex((t) => t.id === id);
    if (index !== -1) {
      this.templates[index] = { ...this.templates[index], ...updates };
    }
  }

  deleteTemplate(id: string): void {
    this.templates = this.templates.filter((t) => t.id !== id);
  }

  // Metrics methods
  getMetrics(period: string = "monthly"): ReputationMetrics | null {
    if (this.metrics && this.metrics.period === period) {
      return this.metrics;
    }
    return null;
  }

  // Utility method to aggregate metrics from reviews
  aggregateMetrics(reviews: Review[]): any {
    let totalRating = 0;
    const sourcesBreakdown: Record<string, number> = {};
    let respondedCount = 0;
    let sentimentTotal = 0;

    reviews.forEach((review) => {
      totalRating += review.rating;

      // Count by source
      if (sourcesBreakdown[review.sourceName]) {
        sourcesBreakdown[review.sourceName]++;
      } else {
        sourcesBreakdown[review.sourceName] = 1;
      }

      // Count responded
      if (review.status === "responded") {
        respondedCount++;
      }

      // Sum sentiment
      if (review.sentiment !== undefined) {
        sentimentTotal += review.sentiment.score;
      }
    });

    return {
      averageRating: reviews.length > 0 ? totalRating / reviews.length : 0,
      totalReviews: reviews.length,
      sourcesBreakdown,
      responseRate: reviews.length > 0 ? respondedCount / reviews.length : 0,
      sentimentScore: reviews.length > 0 ? sentimentTotal / reviews.length : 0,
    };
  }
}

// Create and export an instance of the MockReputationManager
export const mockReputationManager = new MockReputationManager();
